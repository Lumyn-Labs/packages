#pragma once

/**
 * @file TypeConversions.h
 * @brief Centralized conversions between WPILib types and Lumyn SDK types.
 * 
 * This header provides utility functions for converting between WPILib's
 * type system (frc::Color, units::*, etc.) and the Lumyn SDK's types
 * (lumyn_color_t, std::chrono::*, etc.).
 * 
 * Use these utilities throughout the vendordep to ensure consistent
 * and correct type conversions.
 */

#include <frc/util/Color.h>
#include <frc/util/Color8Bit.h>
#include <units/time.h>
#include <lumyn/c/lumyn_sdk.h>
#include <lumyn/domain/command/led/LEDCommand.h>
#include <chrono>
#include <cstdint>

namespace lumyn::util {

//==============================================================================
// Color Conversions
//==============================================================================

/**
 * Convert WPILib frc::Color to SDK lumyn_color_t.
 * 
 * frc::Color stores components as doubles in [0.0, 1.0] range.
 * lumyn_color_t uses uint8_t in [0, 255] range.
 */
inline lumyn_color_t toSdkColor(const frc::Color& color) {
    return {
        static_cast<uint8_t>(color.red * 255),
        static_cast<uint8_t>(color.green * 255),
        static_cast<uint8_t>(color.blue * 255)
    };
}

/**
 * Convert WPILib frc::Color8Bit to SDK lumyn_color_t.
 * 
 * Both use uint8_t [0, 255] range, so this is a direct mapping.
 */
inline lumyn_color_t toSdkColor(const frc::Color8Bit& color) {
    return {
        static_cast<uint8_t>(color.red),
        static_cast<uint8_t>(color.green),
        static_cast<uint8_t>(color.blue)
    };
}

/**
 * Convert WPILib frc::Color to internal AnimationColor struct.
 * 
 * AnimationColor is used in the command protocol layer.
 */
inline lumyn::internal::Command::LED::AnimationColor toAnimationColor(const frc::Color& color) {
    return {
        .r = static_cast<uint8_t>(color.red * 255),
        .g = static_cast<uint8_t>(color.green * 255),
        .b = static_cast<uint8_t>(color.blue * 255)
    };
}

/**
 * Convert WPILib frc::Color8Bit to internal AnimationColor struct.
 */
inline lumyn::internal::Command::LED::AnimationColor toAnimationColor(const frc::Color8Bit& color) {
    return {
        .r = static_cast<uint8_t>(color.red),
        .g = static_cast<uint8_t>(color.green),
        .b = static_cast<uint8_t>(color.blue)
    };
}

/**
 * Convert SDK lumyn_color_t to WPILib frc::Color.
 */
inline frc::Color toWpiColor(const lumyn_color_t& color) {
    return frc::Color(color.r / 255.0, color.g / 255.0, color.b / 255.0);
}

/**
 * Convert SDK lumyn_color_t to WPILib frc::Color8Bit.
 */
inline frc::Color8Bit toWpiColor8Bit(const lumyn_color_t& color) {
    return frc::Color8Bit(color.r, color.g, color.b);
}

//==============================================================================
// Time Conversions
//==============================================================================

/**
 * Convert WPILib units::millisecond_t to std::chrono::milliseconds.
 */
inline std::chrono::milliseconds toChronoMilliseconds(units::millisecond_t ms) {
    return std::chrono::milliseconds(static_cast<int64_t>(ms.value()));
}

/**
 * Convert std::chrono::milliseconds to WPILib units::millisecond_t.
 */
inline units::millisecond_t toWpiMilliseconds(std::chrono::milliseconds ms) {
    return units::millisecond_t(ms.count());
}

/**
 * Convert WPILib units::millisecond_t to raw uint32_t milliseconds.
 * 
 * Useful when interfacing with C APIs or protocol layers that
 * expect plain integer milliseconds.
 */
inline uint32_t toMillisecondsU32(units::millisecond_t ms) {
    auto value = static_cast<int64_t>(ms.value());
    if (value < 0) return 0;
    if (value > UINT32_MAX) return UINT32_MAX;
    return static_cast<uint32_t>(value);
}

/**
 * Convert WPILib units::second_t to raw uint32_t milliseconds.
 */
inline uint32_t toMillisecondsU32(units::second_t sec) {
    return toMillisecondsU32(units::millisecond_t(sec));
}

} // namespace lumyn::util
