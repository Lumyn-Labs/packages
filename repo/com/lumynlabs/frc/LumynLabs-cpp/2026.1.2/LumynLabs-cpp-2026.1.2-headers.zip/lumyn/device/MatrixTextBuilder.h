#pragma once

#include <frc/util/Color8Bit.h>
#include <units/time.h>
#include "connectorXVariant/c_ConnectorX.h"
#include <string_view>
#include <optional>
#include <stdexcept>

namespace lumyn
{
  namespace device
  {
    // Forward declarations
    class ConnectorX;
    class ConnectorXAnimate;

    /**
     * Builder for setting matrix text with a fluent API.
     *
     * Usage with ConnectorX:
     * ```cpp
     * m_cx.SetText("HELLO")
     *   .ForZone("front-matrix")
     *   .WithColor({255, 0, 0})
     *   .WithDelay(50_ms)
     *   .WithDirection(MatrixTextScrollDirection::LEFT)
     *   .WithFont(MatrixTextFont::FREE_SANS_9)
     *   .WithBackgroundColor({0, 0, 64})
     *   .WithSmoothScroll(true)
     *   .RunOnce(false);
     * ```
     *
     * Usage with ConnectorXAnimate:
     * ```cpp
     * m_animate.SetText("HELLO")
     *   .ForZone("front-matrix")
     *   .WithColor({255, 0, 0})
     *   .WithDelay(50_ms)
     *   .WithDirection(MatrixTextScrollDirection::LEFT)
     *   .WithFont(MatrixTextFont::FREE_SANS_9)
     *   .WithBackgroundColor({0, 0, 64})
     *   .WithSmoothScroll(true)
     *   .RunOnce(false);
     * ```
     */
    template <typename DeviceType>
    class MatrixTextBuilder
    {
    public:
      MatrixTextBuilder(DeviceType *device, std::string_view text)
          : _device(device), _text(text)
      {
      }

      /**
       * Set the target zone for this text.
       */
      MatrixTextBuilder &ForZone(std::string_view zoneId)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _zoneId = zoneId;
        _groupId = std::nullopt;
        return *this;
      }

      /**
       * Set the target group for this text.
       */
      MatrixTextBuilder &ForGroup(std::string_view groupId)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _groupId = groupId;
        _zoneId = std::nullopt;
        return *this;
      }

      /**
       * Set the foreground color for this text.
       */
      MatrixTextBuilder &WithColor(frc::Color color)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _color = color;
        return *this;
      }

      /**
       * Set the background color for this text.
       * Note: Background is only visible when WithShowBackground(true) is set.
       */
      MatrixTextBuilder &WithBackgroundColor(frc::Color color)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _bgColor = color;
        return *this;
      }

      /**
       * Set the delay between scroll steps.
       */
      MatrixTextBuilder &WithDelay(units::millisecond_t delay)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _delay = delay;
        return *this;
      }

      /**
       * Set the scroll direction for this text.
       */
      MatrixTextBuilder &WithDirection(lumyn::internal::Command::LED::MatrixTextScrollDirection direction)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _direction = direction;
        return *this;
      }

      /**
       * Set the font for this text.
       */
      MatrixTextBuilder &WithFont(lumyn::internal::Command::LED::MatrixTextFont font)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _font = font;
        return *this;
      }

      /**
       * Set the text alignment (used when noScroll is true).
       */
      MatrixTextBuilder &WithAlign(lumyn::internal::Command::LED::MatrixTextAlign align)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _align = align;
        return *this;
      }

      /**
       * Enable or disable smooth scrolling (pixel-by-pixel vs character-by-character).
       */
      MatrixTextBuilder &WithSmoothScroll(bool enabled)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _flags.smoothScroll = enabled ? 1 : 0;
        return *this;
      }

      /**
       * Enable or disable background color rendering.
       */
      MatrixTextBuilder &WithShowBackground(bool enabled)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _flags.showBackground = enabled ? 1 : 0;
        return *this;
      }

      /**
       * Enable or disable ping-pong scrolling (bounces back and forth).
       */
      MatrixTextBuilder &WithPingPong(bool enabled)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _flags.pingPong = enabled ? 1 : 0;
        return *this;
      }

      /**
       * Enable or disable scrolling. When true, text is static and alignment is used.
       */
      MatrixTextBuilder &WithNoScroll(bool enabled)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _flags.noScroll = enabled ? 1 : 0;
        return *this;
      }

      /**
       * Set the vertical offset for fine positioning.
       */
      MatrixTextBuilder &WithYOffset(int8_t offset)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _yOffset = offset;
        return *this;
      }

      /**
       * Set whether the text should scroll once or loop, and execute the command.
       */
      MatrixTextBuilder &RunOnce(bool oneShot)
      {
        if (_executed)
        {
          throw std::runtime_error("Builder has already been executed");
        }
        _oneShot = oneShot;
        execute();
        return *this;
      }

      /**
       * Execute the text command.
       */
      void execute()
      {
        if (_executed)
        {
          return;
        }

        if (!_zoneId.has_value() && !_groupId.has_value())
        {
          throw std::runtime_error("Must call ForZone() or ForGroup() before executing");
        }

        // Convert frc::Color to AnimationColor
        lumyn::internal::Command::LED::AnimationColor fgColor{
            static_cast<uint8_t>(_color.red * 255),
            static_cast<uint8_t>(_color.green * 255),
            static_cast<uint8_t>(_color.blue * 255)};
        lumyn::internal::Command::LED::AnimationColor bgColor{
            static_cast<uint8_t>(_bgColor.red * 255),
            static_cast<uint8_t>(_bgColor.green * 255),
            static_cast<uint8_t>(_bgColor.blue * 255)};

// Suppress deprecation warnings - builders intentionally use deprecated methods internally
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
        if (_zoneId.has_value())
        {
          _device->SetText(_zoneId.value(), _text, _color, _direction, _delay, _oneShot,
                           bgColor, _font, _align, _flags, _yOffset);
        }
        else
        {
          _device->SetGroupText(_groupId.value(), _text, _color, _direction, _delay, _oneShot,
                                bgColor, _font, _align, _flags, _yOffset);
        }
#pragma GCC diagnostic pop

        _executed = true;
      }

    private:
      DeviceType *_device;
      std::string_view _text;
      std::optional<std::string_view> _zoneId;
      std::optional<std::string_view> _groupId;
      frc::Color _color{1.0, 1.0, 1.0};                                                                                                    // Default white
      frc::Color _bgColor{0.0, 0.0, 0.0};                                                                                                  // Default black
      units::millisecond_t _delay{50};                                                                                                     // Default 50ms
      lumyn::internal::Command::LED::MatrixTextScrollDirection _direction{lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT}; // Default left
      lumyn::internal::Command::LED::MatrixTextFont _font{lumyn::internal::Command::LED::MatrixTextFont::BUILTIN};                         // Default built-in font
      lumyn::internal::Command::LED::MatrixTextAlign _align{lumyn::internal::Command::LED::MatrixTextAlign::LEFT};                         // Default left align
      lumyn::internal::Command::LED::MatrixTextFlags _flags{0, 0, 0, 0, 0};                                                                // All flags disabled by default
      int8_t _yOffset{0};                                                                                                                  // Default no offset
      bool _oneShot{false};
      bool _executed{false};
    };

  } // namespace device
} // namespace lumyn
