#pragma once

#include <span>
#include <string>
#include <string_view>
#include <vector>
#include <cstdint>

#include <frc/AddressableLED.h>

#include "connectorXVariant/c_ConnectorX.h"

namespace lumyn
{
  namespace device
  {
    /**
     * DirectLED provides efficient, low-level LED control with delta compression.
     *
     * This class accepts WPILib's AddressableLED::LEDData spans and sends the data
     * directly to ConnectorX hardware with automatic delta compression for optimal
     * bandwidth usage.
     *
     * Use this when you need per-pixel control with the WPILib LED patterns API,
     * while still benefiting from ConnectorX's efficient protocol.
     *
     * Example usage:
     * @code
     * // Create your WPILib buffer
     * std::array<frc::AddressableLED::LEDData, 60> ledBuffer;
     *
     * // Create DirectLED for a zone
     * lumyn::device::DirectLED directLed(cxInstance, "zone1", 60);
     *
     * // In your periodic method:
     * for (int i = 0; i < 60; i++) {
     *   ledBuffer[i].SetRGB(i * 4, 0, 255 - i * 4); // gradient
     * }
     * directLed.Update(ledBuffer);
     * @endcode
     */
    class DirectLED
    {
    public:
      /** Bytes per LED (RGB = 3) */
      static constexpr int kBytesPerLed = 3;

      /**
       * Creates a DirectLED controller for a zone.
       *
       * @param instance The ConnectorX native instance
       * @param zoneId The zone ID to control
       * @param numLeds Number of LEDs in the zone
       * @param fullRefreshInterval How often to force a full refresh (default 100, 0 to disable)
       */
      DirectLED(lumyn::internal::c_ConnectorX::ConnectorX_int *instance,
                std::string_view zoneId,
                size_t numLeds,
                int fullRefreshInterval = 100);

      ~DirectLED();

      // Non-copyable
      DirectLED(const DirectLED &) = delete;
      DirectLED &operator=(const DirectLED &) = delete;

      // Movable
      DirectLED(DirectLED &&other) noexcept;
      DirectLED &operator=(DirectLED &&other) noexcept;

      /**
       * Update the LEDs with data from a WPILib LED buffer.
       * Uses delta compression to only send changed pixels.
       *
       * @param ledData Span of LED data from WPILib
       * @return true if the update was successful
       */
      bool Update(std::span<const frc::AddressableLED::LEDData> ledData);

      /**
       * Update the LEDs with raw RGB data.
       * Uses delta compression to only send changed pixels.
       *
       * @param rgbData Raw RGB bytes (3 bytes per LED: R, G, B)
       * @return true if the update was successful
       */
      bool Update(std::span<const uint8_t> rgbData);

      /**
       * Force a full update of the LEDs (no delta compression).
       * Use this after significant changes or to ensure synchronization.
       *
       * @param ledData Span of LED data from WPILib
       * @return true if the update was successful
       */
      bool ForceFullUpdate(std::span<const frc::AddressableLED::LEDData> ledData);

      /**
       * Force a full update with raw RGB data.
       *
       * @param rgbData Raw RGB bytes (3 bytes per LED: R, G, B)
       * @return true if the update was successful
       */
      bool ForceFullUpdate(std::span<const uint8_t> rgbData);

      /**
       * Reset the internal buffer state.
       * Forces the next update to be a full update.
       */
      void Reset();

      /**
       * Set the full refresh interval.
       *
       * @param interval Number of updates between full refreshes (0 to disable)
       */
      void SetFullRefreshInterval(int interval);

      /**
       * Get the number of LEDs this DirectLED controls.
       *
       * @return The number of LEDs
       */
      size_t GetLength() const { return _numLeds; }

      /**
       * Get the expected buffer length in bytes.
       *
       * @return The expected number of bytes (numLeds * 3)
       */
      size_t GetExpectedBufferLength() const { return _numLeds * kBytesPerLed; }

      /**
       * Check if the DirectLED was successfully initialized.
       *
       * @return true if initialized
       */
      bool IsInitialized() const { return _initialized; }

      /**
       * Get the zone ID this DirectLED controls.
       *
       * @return The zone ID
       */
      const std::string &GetZoneId() const { return _zoneId; }

    private:
      void ConvertLEDDataToRGB(std::span<const frc::AddressableLED::LEDData> ledData);

      lumyn::internal::c_ConnectorX::ConnectorX_int *_instance;
      std::string _zoneId;
      size_t _numLeds;
      std::vector<uint8_t> _rgbBuffer;
      bool _initialized = false;
    };

  } // namespace device
} // namespace lumyn
