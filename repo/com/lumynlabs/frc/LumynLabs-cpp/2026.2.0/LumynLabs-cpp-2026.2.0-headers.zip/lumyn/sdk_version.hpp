#pragma once

namespace lumyn {
inline constexpr int VersionMajor = 4;
inline constexpr int VersionMinor = 2;
inline constexpr int VersionPatch = 0;
inline constexpr const char* Version = "4.2.0";
} // namespace lumyn
