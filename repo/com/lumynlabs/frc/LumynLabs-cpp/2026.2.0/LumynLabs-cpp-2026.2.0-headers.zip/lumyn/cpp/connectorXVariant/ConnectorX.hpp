#pragma once

#include <string>
#include <string_view>
#include <vector>

#include "lumyn/cpp/export.hpp"
#include "lumyn/cpp/connectorXVariant/BaseConnectorXVariant.hpp"

namespace lumyn::device {

/**
 * @brief ConnectorX device with full LED and module support
 *
 * Thin C++ wrapper around the C SDK. All device logic is in the C SDK layer.
 * Module support is inherited from BaseConnectorXVariant.
 *
 * Architecture: common -> C SDK -> C++ SDK (this) -> Driver -> WPILib API
 */
class LUMYN_SDK_CPP_API ConnectorX : public BaseConnectorXVariant {
public:
  ConnectorX();
  ~ConnectorX() override;

  ConnectorX(const ConnectorX&) = delete;
  ConnectorX& operator=(const ConnectorX&) = delete;
  ConnectorX(ConnectorX&&) = delete;
  ConnectorX& operator=(ConnectorX&&) = delete;

  // Event polling control
  ConnectorX& SetAutoPollEvents(bool enabled);

  // RestartDevice - ConnectorX-specific
  void RestartDevice(uint32_t delay_ms = 0);

private:
  cx_t *c_handle_{nullptr};
  bool owns_c_handle_{false};
};

} // namespace lumyn::device
