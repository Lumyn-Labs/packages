#pragma once

#include "lumyn/cpp/export.hpp"
#include "lumyn/cpp/connectorXVariant/BaseConnectorXVariant.hpp"

namespace lumyn::device {

/**
 * @brief ConnectorXAnimate device with LED and limited module support
 *
 * Thin C++ wrapper around the C SDK. This variant supports I2C modules
 * (max 2), but does not support SPI, UART, DIO, or AIO modules due to
 * hardware limitations.
 *
 * Module support is inherited from BaseConnectorXVariant and works identically
 * to ConnectorX - the hardware/firmware enforces the I2C-only and 2-module limit.
 *
 * Architecture: common -> C SDK -> C++ SDK (this) -> Driver -> WPILib API
 */
class LUMYN_SDK_CPP_API ConnectorXAnimate : public BaseConnectorXVariant {
public:
  ConnectorXAnimate();
  ~ConnectorXAnimate() override;

  ConnectorXAnimate(const ConnectorXAnimate&) = delete;
  ConnectorXAnimate& operator=(const ConnectorXAnimate&) = delete;
  ConnectorXAnimate(ConnectorXAnimate&&) = delete;
  ConnectorXAnimate& operator=(ConnectorXAnimate&&) = delete;

  // SetAutoPollEvents - return *this for chaining
  ConnectorXAnimate& SetAutoPollEvents(bool enabled);

private:
  cx_animate_t *c_handle_{nullptr};
  bool owns_c_handle_{false};
};

} // namespace lumyn::device
