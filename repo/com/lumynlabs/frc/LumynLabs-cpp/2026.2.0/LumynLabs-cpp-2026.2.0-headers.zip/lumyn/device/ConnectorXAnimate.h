#pragma once

#include <frc/util/Color8Bit.h>
#include <units/time.h>

#include "lumyn/led/Animation.h"
#include "lumyn/device/IModuleDevice.h"
#include "connectorXVariant/c_ConnectorX.h"
#include "lumyn/connection/USBPort.h"
#include "lumyn/configuration/Configuration.h"
#include "device/ConnectorXSimDevice.h"
#include "lumyn/alerts/DeviceAlertManager.h"
#include "lumyn/device/AnimationBuilder.h"
#include "lumyn/device/ImageSequenceBuilder.h"
#include "lumyn/device/MatrixTextBuilder.h"
#include "lumyn/device/DirectLED.h"
#include "lumyn/util/TypeConversions.h"

#include <memory>
#include <vector>
#include <functional>
#include <mutex>
#include <thread>
#include <atomic>
#include <optional>
#include <string>
#include <unordered_map>

// Forward declarations
namespace lumyn
{
  namespace device
  {
    template <typename DeviceType>
    class AnimationBuilder;
    template <typename DeviceType>
    class ImageSequenceBuilder;
    template <typename DeviceType>
    class MatrixTextBuilder;
  }
}

namespace lumyn
{
  namespace device
  {
    class ConnectorXAnimate : public IModuleDevice
    {
    public:
      ConnectorXAnimate();

      ~ConnectorXAnimate();

      ConnectorXAnimate(const ConnectorXAnimate &other) = delete;
      ConnectorXAnimate &operator=(const ConnectorXAnimate &other) = delete;
      ConnectorXAnimate(ConnectorXAnimate &&other) = delete;
      ConnectorXAnimate &operator=(ConnectorXAnimate &&other) = delete;

      bool Connect(lumyn::connection::USBPort port);
      bool IsConnected(void);
      lumyn::internal::Eventing::Status GetCurrentStatus(void);
      std::optional<lumyn::internal::Eventing::Event> GetLatestEvent(void);
      std::vector<lumyn::internal::Eventing::Event> GetEvents(void);

      ConnectorXAnimate &AddEventHandler(std::function<void(const lumyn::internal::Eventing::Event &)> handler);

      // Set all LEDs on a zone to a color, mirrors WPI way of setting LEDs
      // Should have the same result as SetAnimation(fill, zone, color)
      void SetColor(std::string_view zoneID, frc::Color color);
      void SetGroupColor(std::string_view groupID, frc::Color color);

      /**
       * Set an animation on a zone.
       *
       * @deprecated Use the builder API instead: SetAnimation(Animation).ForZone(...). This method will be removed in 2027.
       * Use: SetAnimation(Animation::Chase).ForZone("zone1").WithColor(...).WithDelay(...).Reverse(false).RunOnce(false);
       */
      void SetAnimation(std::string_view zoneID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay = 250_ms, bool reversed = false, bool oneShot = false);

      /**
       * Set an animation on a group of zones.
       *
       * @deprecated Use the builder API instead: SetAnimation(Animation).ForGroup(...). This method will be removed in 2027.
       * Use: SetAnimation(Animation::Chase).ForGroup("group1").WithColor(...).WithDelay(...).Reverse(false).RunOnce(false);
       */
      void SetGroupAnimation(std::string_view groupID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay = 250_ms, bool reversed = false, bool oneShot = false);

      /**
       * Start building an animation command with a fluent API.
       *
       * Usage:
       * ```cpp
       * m_animate.SetAnimation(Animation::Chase)
       *   .ForZone("front")
       *   .WithColor({255, 0, 0})
       *   .WithDelay(40_ms)
       *   .Reverse(false)
       *   .RunOnce(false);
       * ```
       */
      AnimationBuilder<ConnectorXAnimate> SetAnimation(lumyn::led::Animation animation);

      void SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID);
      void SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID);

      void SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color, bool setColor = false, bool oneShot = false);
      void SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color, bool setColor = false, bool oneShot = false);

      /**
       * Start building an image sequence command with a fluent API.
       *
       * Usage:
       * ```cpp
       * m_animate.SetImageSequence("Emoji_16x16_unknown")
       *   .ForZone("front-matrix")
       *   .WithColor({120, 0, 100})
       *   .Reverse(false)
       *   .RunOnce(false);
       * ```
       */
      ImageSequenceBuilder<ConnectorXAnimate> SetImageSequence(std::string_view sequenceId);

      /**
       * Set text on a matrix zone.
       *
       * @deprecated Use the builder API instead: SetText(text).ForZone(...). This method will be removed in 2027.
       * Use: SetText("HELLO").ForZone("zone1").WithColor(...).WithDelay(...).WithDirection(...).RunOnce(false);
       */
      [[deprecated("Use the builder API instead: SetText(text).ForZone(...)")]]
      void SetText(std::string_view zoneID, std::string_view text, frc::Color color,
                   lumyn::internal::Command::LED::MatrixTextScrollDirection direction = lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT,
                   units::millisecond_t delayMs = 500_ms, bool oneShot = false,
                   lumyn::internal::Command::LED::AnimationColor bgColor = {0, 0, 0},
                   lumyn::internal::Command::LED::MatrixTextFont font = lumyn::internal::Command::LED::MatrixTextFont::BUILTIN,
                   lumyn::internal::Command::LED::MatrixTextAlign align = lumyn::internal::Command::LED::MatrixTextAlign::LEFT,
                   lumyn::internal::Command::LED::MatrixTextFlags flags = {0, 0, 0, 0, 0},
                   int8_t yOffset = 0);

      /**
       * Set text on a group of matrix zones.
       *
       * @deprecated Use the builder API instead: SetText(text).ForGroup(...). This method will be removed in 2027.
       * Use: SetText("HELLO").ForGroup("group1").WithColor(...).WithDelay(...).WithDirection(...).RunOnce(false);
       */
      [[deprecated("Use the builder API instead: SetText(text).ForGroup(...)")]]
      void SetGroupText(std::string_view groupID, std::string_view text, frc::Color color,
                        lumyn::internal::Command::LED::MatrixTextScrollDirection direction = lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT,
                        units::millisecond_t delayMs = 500_ms, bool oneShot = false,
                        lumyn::internal::Command::LED::AnimationColor bgColor = {0, 0, 0},
                        lumyn::internal::Command::LED::MatrixTextFont font = lumyn::internal::Command::LED::MatrixTextFont::BUILTIN,
                        lumyn::internal::Command::LED::MatrixTextAlign align = lumyn::internal::Command::LED::MatrixTextAlign::LEFT,
                        lumyn::internal::Command::LED::MatrixTextFlags flags = {0, 0, 0, 0, 0},
                        int8_t yOffset = 0);

      /**
       * Start building a matrix text command with a fluent API.
       *
       * Usage:
       * ```cpp
       * m_animate.SetText("HELLO")
       *   .ForZone("front-matrix")
       *   .WithColor({255, 0, 0})
       *   .WithDelay(50_ms)
       *   .WithDirection(MatrixTextScrollDirection::LEFT)
       *   .RunOnce(false);
       * ```
       */
      MatrixTextBuilder<ConnectorXAnimate> SetText(std::string_view text);

      // Simulation-facing API: apply a configuration (channels + zones) directly to the sim
      void ApplyConfiguration(const lumyn::internal::Configuration::LumynConfiguration &config);

      /**
       * Load configuration from JSON file in the deploy directory.
       * Looks for deploy/lumyn_config.json by default, or a custom filename.
       */
      std::optional<lumyn::internal::Configuration::LumynConfiguration> LoadConfigurationFromDeploy(const std::string &configFileName = "lumyn_config.json");

      /**
       * Request configuration from the connected device.
       */
      std::optional<lumyn::internal::Configuration::LumynConfiguration> RequestConfig();

      // System
      void RestartDevice(units::millisecond_t delay = 0_ms);

      void SetAlertsEnabled(bool enabled)
      {
        if (_alertManager)
        {
          _alertManager->setAlertsEnabled(enabled);
        }
      }

      /**
       * Enable/disable background event polling. When disabled, call PollEvents()
       * manually from your loop to dispatch handlers on the calling thread.
       */
      ConnectorXAnimate &SetAutoPollEvents(bool enabled);

      /**
       * Poll for events once and dispatch handlers on the calling thread. Intended
       * for use when auto polling is disabled.
       */
      void PollEvents();

      // ========== Module Support ==========
      // ConnectorXAnimate supports limited module connectivity (I2C only, max 2 modules).

      /**
       * Register a module for data reception.
       *
       * @param moduleID The module identifier as configured on the device
       * @param callback Optional callback invoked when module data arrives.
       *        Pass nullptr to register without a callback (use GetLatestModuleData to poll).
       */
      void RegisterModule(const std::string &moduleID,
                          std::function<void(uint16_t id, const std::vector<uint8_t> &payload)> callback) override;

      /**
       * Get the latest module data for a specific module ID.
       *
       * @param moduleID The module identifier
       * @param out Output vector of (id, payload) pairs
       * @return true if data was available
       */
      bool GetLatestModuleData(const std::string &moduleID,
                               std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &out) override;

      /**
       * Create a DirectLED controller for efficient LED buffer updates.
       *
       * @param zoneId The zone ID to control
       * @param numLeds Number of LEDs in the zone
       * @param fullRefreshInterval How often to force a full update (0 = never auto-refresh)
       * @return DirectLED controller instance
       */
      DirectLED CreateDirectLED(std::string_view zoneId,
                                size_t numLeds,
                                int fullRefreshInterval = 100)
      {
        return DirectLED(_connectorXInternal, zoneId, numLeds, fullRefreshInterval);
      }

    private:
      lumyn::internal::c_ConnectorX::ConnectorX_int *_connectorXInternal;
      std::unique_ptr<lumyn::alerts::DeviceAlertManager> _alertManager;
      std::vector<std::function<void(const lumyn::internal::Eventing::Event &)>> _eventHandlers;
      std::mutex _eventHandlersMutex;
      std::atomic<bool> _autoPollEvents{true};

      // Module support
      std::unordered_map<std::string, std::function<void(uint16_t, const std::vector<uint8_t> &)>> _moduleCallbacks;
      std::mutex _moduleCallbacksMutex;
      std::atomic<bool> _pollingRunning{false};
      std::atomic<bool> _modulePollingEnabled{false};
      std::thread _pollingThread;

      void NotifyEventHandlers(const lumyn::internal::Eventing::Event &event);
      void PollingLoop();
      void PollModulesOnce();
      void PollEventsOnce();
      void EnsurePollingThread();
      void StopPollingThread();
      bool ShouldRunPollingLoop();
      bool HasRegisteredModules();
    };
  }
}
