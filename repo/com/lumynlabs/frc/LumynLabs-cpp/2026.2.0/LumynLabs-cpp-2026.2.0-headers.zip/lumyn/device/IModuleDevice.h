#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <utility>
#include <vector>

namespace lumyn
{
  namespace device
  {
    /**
     * Interface for devices that support module data reception.
     *
     * Both ConnectorX and ConnectorXAnimate implement this interface,
     * allowing module helpers (ModuleBase, VL53L1XModule, etc.) to work
     * with either device type without templates.
     */
    class IModuleDevice
    {
    public:
      virtual ~IModuleDevice() = default;

      /**
       * Register a module for data reception.
       *
       * @param moduleID The module identifier as configured on the device
       * @param callback Optional callback invoked when module data arrives.
       *        Pass nullptr to register without a callback (use GetLatestModuleData to poll).
       */
      virtual void RegisterModule(const std::string &moduleID,
                                  std::function<void(uint16_t id, const std::vector<uint8_t> &payload)> callback) = 0;

      /**
       * Get the latest module data for a specific module ID.
       *
       * @param moduleID The module identifier
       * @param out Output vector of (id, payload) pairs
       * @return true if data was available
       */
      virtual bool GetLatestModuleData(const std::string &moduleID,
                                       std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &out) = 0;
    };
  } // namespace device
} // namespace lumyn
