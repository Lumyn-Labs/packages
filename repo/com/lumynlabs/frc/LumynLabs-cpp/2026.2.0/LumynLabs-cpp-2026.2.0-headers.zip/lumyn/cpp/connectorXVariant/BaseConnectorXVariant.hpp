#pragma once

#include "lumyn/cpp/export.hpp"
#include "lumyn/cpp/device/DirectLED.hpp"
#include "lumyn/cpp/device/builder/AnimationBuilder.hpp"
#include "lumyn/cpp/device/builder/ImageSequenceBuilder.hpp"
#include "lumyn/cpp/device/builder/MatrixTextBuilder.hpp"
#include "lumyn/cpp/types.hpp"
#include "lumyn/c/lumyn_sdk.h"
#include "lumyn/c/serial_io.h"
#include "lumyn/types/events.h"
#include "lumyn/types/status.h"
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace lumyn::modules
{
  class ModuleDataDispatcher;
}

namespace lumyn::device
{

  /**
   * @brief Base class for ConnectorX device variants (thin C++ wrapper around C API)
   *
   * This class wraps the C SDK API, providing C++ conveniences like std::string,
   * std::optional, and builder patterns. All actual device logic is implemented
   * in the C SDK layer.
   *
   * Module support is provided through the C API vtable. Different hardware variants
   * may have different module capabilities (e.g., ConnectorX supports all module types,
   * while Animate only supports I2C).
   *
   * Architecture: common -> C SDK -> C++ SDK (this) -> Driver -> WPILib API
   *
   * Derived classes only need to:
   *   - Call SetCBasePtr() after creating C handle
   *   - Add device-specific functionality
   */
  class LUMYN_SDK_CPP_API BaseConnectorXVariant
  {
  public:
    BaseConnectorXVariant();
    virtual ~BaseConnectorXVariant();

    BaseConnectorXVariant(const BaseConnectorXVariant &) = delete;
    BaseConnectorXVariant &operator=(const BaseConnectorXVariant &) = delete;
    BaseConnectorXVariant(BaseConnectorXVariant &&) = delete;
    BaseConnectorXVariant &operator=(BaseConnectorXVariant &&) = delete;

    // Connection / status - delegates to C API
    ::lumyn_error_t Connect(const ::lumyn_serial_io_t &io);
    ::lumyn_error_t Connect(const std::string &port, std::optional<int> baud = std::nullopt);
    void Disconnect();
    bool IsConnected() const;
    ::lumyn::ConnectionStatus GetCurrentStatus() const;
    ::lumyn::Status GetDeviceHealth() const;

    // Events - delegates to C API
    ::lumyn_error_t AddEventHandler(std::function<void(const ::lumyn::Event &)> handler);
    ::lumyn_error_t GetLatestEvent(::lumyn_event_t &out_event);
    std::optional<::lumyn::Event> GetLatestEvent();
    std::vector<::lumyn::Event> GetEvents();
    void SetAutoPollEvents(bool enabled);
    void PollEvents();

    // Configuration - delegates to C API
    ::lumyn_error_t RequestConfig(std::string &out_json, uint32_t timeout_ms = 1000);
    bool ApplyConfigurationJson(const std::string &json);
    bool LoadConfigurationFromFile(const std::string &path);

    // LED control - delegates to C API
    void SetColor(std::string_view zone_id, ::lumyn_color_t color) const;
    void SetGroupColor(std::string_view group_id, ::lumyn_color_t color) const;
    AnimationBuilder SetAnimation(::lumyn::led::Animation animation);
    ImageSequenceBuilder SetImageSequence(std::string_view sequence_id);
    MatrixTextBuilder SetText(std::string_view text);

    // Animation sequences (pre-defined in config JSON)
    void SetAnimationSequence(std::string_view zone_id, std::string_view sequence_id);
    void SetGroupAnimationSequence(std::string_view group_id, std::string_view sequence_id);

    // Direct LED buffer helpers
    ::lumyn_error_t SendDirectBuffer(std::string_view zone_id, const uint8_t *data, size_t length, bool delta);
    ::lumyn_error_t SendDirectBuffer(uint16_t zone_hash, const uint8_t *data, size_t length, bool delta);
    ::lumyn::device::DirectLED CreateDirectLED(std::string_view zone_id, size_t num_leds, int full_refresh_interval_ms = 100);

    // Send pre-built raw command bytes
    void SendRawCommand(const uint8_t *data, size_t length);

    // Send LED command (used by builders)
    void SendLEDCommand(const void *data, uint32_t length);

    // =========================================================================
    // Module support - available on all device variants via C API vtable
    // =========================================================================

    /**
     * @brief Get the latest data from a specific module
     * @param module_id The identifier of the module
     * @param out Vector to store the retrieved data
     * @return LUMYN_OK on success, LUMYN_ERR_NOT_SUPPORTED if device doesn't support modules
     */
    lumyn_error_t GetLatestModuleData(std::string_view module_id, std::vector<uint8_t> &out);

    /**
     * @brief Register a callback for a specific module
     * @param module_id The identifier of the module
     * @param callback Function to be called when module data is available
     */
    void RegisterModule(std::string_view module_id, std::function<void(const std::vector<uint8_t> &)> callback);

    /**
     * @brief Enable or disable module polling
     * @param enabled true to enable, false to disable
     */
    void SetModulePollingEnabled(bool enabled);

    /**
     * @brief Manually poll all registered modules once
     */
    void PollModules();

    /**
     * @brief Get the module data dispatcher for typed module helpers
     * @return Reference to the ModuleDataDispatcher
     */
    ::lumyn::modules::ModuleDataDispatcher &GetModuleDispatcher();

    /**
     * @brief Set callback for connection state changes
     */
    void SetConnectionStateCallback(std::function<void(bool)> callback);

    // Get cx_base_t* for C API calls
    cx_base_t *GetCBasePtr() { return c_base_ptr_; }
    const cx_base_t *GetCBasePtr() const { return c_base_ptr_; }

  protected:
    // Set cx_base_t* (called by derived class after creating C handle)
    void SetCBasePtr(cx_base_t *base_ptr) { c_base_ptr_ = base_ptr; }

    // Hook for derived classes to handle disconnect cleanup
    virtual void OnDisconnect();

  private:
    void EnsureModuleRegistered(std::string_view module_id);
    void ClearModuleCache();
    bool PopModuleData(std::string_view module_id, std::vector<uint8_t> &out);
    static void HandleModuleData(const char *module_id, const uint8_t *data, size_t len, void *user);

    cx_base_t *c_base_ptr_{nullptr}; // Pointer to C struct
    std::unique_ptr<std::function<void(bool)>> connection_callback_;
    std::unique_ptr<::lumyn::modules::ModuleDataDispatcher> module_dispatcher_;
    std::mutex module_cache_mutex_;
    std::unordered_map<std::string, std::deque<std::vector<uint8_t>>> module_cache_;
    std::unordered_set<std::string> registered_modules_;
    std::unordered_map<std::string, std::function<void(const std::vector<uint8_t> &)>> module_callbacks_;
    bool module_polling_enabled_{false};
  };

} // namespace lumyn::device
