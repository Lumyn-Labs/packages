package com.lumynlabs.devices;

import java.util.Optional;

import com.lumynlabs.domain.event.DeviceStatus;
import com.lumynlabs.domain.event.Event;
import com.lumynlabs.interfaces.IEventCallback;
import com.lumynlabs.jni.LumynJNI;
import edu.wpi.first.wpilibj.SerialPort;

public abstract class ConnectorXBase implements AutoCloseable {
  protected long _instance;

  public ConnectorXBase() {
    _instance = LumynJNI.CreateInstance();
  }

  @Override
  public void close() throws Exception {
    LumynJNI.DeleteInstance(_instance);
  }

  public boolean Connect(SerialPort.Port port) {
    return LumynJNI.Connect(_instance, port.value);
  }

  public boolean IsConnected() {
    return LumynJNI.IsConnected(_instance);
  }

  public DeviceStatus GetCurrentStatus() {
    return DeviceStatus.values()[(LumynJNI.GetCurrentStatus(_instance))];
  }

  public Optional<Event> GetLatestEvent() {
    Event evt = new Event();
    boolean hasEvent = LumynJNI.GetLatestEvent(_instance, evt);

    if (hasEvent) {
      return Optional.of(evt);
    }

    return Optional.empty();
  }

  public void SetEventCallback(IEventCallback cb) {
    LumynJNI.SetEventCallback(_instance, cb);
  }
}
