package com.lumynlabs.domain.event;

public enum EventType {
  BeginInitialization(0),
  FinishInitialization(1 << 0),
  Enabled(1 << 1),
  Disabled(1 << 2),
  Connected(1 << 3),
  Disconnected(1 << 4),
  Error(1 << 5),
  FatalError(1 << 6),
  RegisteredEntity(1 << 7),
  Custom(1 << 8),
  PinInterrupt(1 << 9),
  HeartBeat(1 << 10);

  public final long value;

  EventType(long value) {
    this.value = value;
  }
}
