package com.lumynlabs.interfaces;

import com.lumynlabs.domain.event.Event;

public interface IEventCallback {
  void HandleEvent(Event event);
}
