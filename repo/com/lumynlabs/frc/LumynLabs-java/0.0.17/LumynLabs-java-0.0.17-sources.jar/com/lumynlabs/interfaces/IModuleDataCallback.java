package com.lumynlabs.interfaces;

import com.lumynlabs.domain.module.NewDataInfo;

public interface IModuleDataCallback {
  void HandleData(NewDataInfo data);
}
