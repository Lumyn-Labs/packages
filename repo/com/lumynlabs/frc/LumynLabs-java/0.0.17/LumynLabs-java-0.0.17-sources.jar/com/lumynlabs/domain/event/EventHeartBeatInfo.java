package com.lumynlabs.domain.event;

public class EventHeartBeatInfo {
  public DeviceStatus status;
  public byte enabled;
  public byte connectedUSB;
  public byte canOK;
}
