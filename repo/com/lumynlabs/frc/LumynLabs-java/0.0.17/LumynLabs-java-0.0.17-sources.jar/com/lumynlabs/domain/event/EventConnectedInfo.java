package com.lumynlabs.domain.event;

public class EventConnectedInfo {
  public EventConnectionType type;
}
