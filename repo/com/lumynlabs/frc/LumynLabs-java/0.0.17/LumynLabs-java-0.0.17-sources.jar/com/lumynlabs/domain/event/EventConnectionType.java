package com.lumynlabs.domain.event;

public enum EventConnectionType {
  USB(0),
  WebUSB(1),
  I2C(2),
  CAN(3);

  public final int value;

  EventConnectionType(int value) {
    this.value = value;
  }
}
