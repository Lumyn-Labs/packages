package com.lumynlabs.jni;

import java.util.concurrent.atomic.AtomicBoolean;

import com.lumynlabs.domain.event.Event;
import com.lumynlabs.domain.led.Animation;
import com.lumynlabs.domain.led.AnimationColor;
import com.lumynlabs.domain.led.MatrixTextScrollDirection;
import com.lumynlabs.interfaces.IEventCallback;
import com.lumynlabs.interfaces.IModuleDataCallback;

import edu.wpi.first.wpilibj.SerialPort.Port;

/**
 * Demo class for loading the driver via JNI.
 */
public class LumynJNI {
  static boolean libraryLoaded = false;

  /**
   * Helper class for determining whether or not to load the driver on static
   * initialization.
   */
  public static class Helper {
    private static AtomicBoolean extractOnStaticLoad = new AtomicBoolean(true);

    /**
     * Get whether to load the driver on static init.
     * 
     * @return true if the driver will load on static init
     */
    public static boolean getExtractOnStaticLoad() {
      return extractOnStaticLoad.get();
    }

    /**
     * Set whether to load the driver on static init.
     * 
     * @param load the new value
     */
    public static void setExtractOnStaticLoad(boolean load) {
      extractOnStaticLoad.set(load);
    }
  }

  static {
    if (Helper.getExtractOnStaticLoad()) {
      System.loadLibrary("LumynDriver");
      libraryLoaded = true;
    }
  }

  /**
   * Force load the library.
   */
  public static synchronized void forceLoad() {
    if (libraryLoaded) {
      return;
    }
    System.loadLibrary("LumynDriver");
    libraryLoaded = true;
  }

  public static native long CreateInstance();

  public static native void DeleteInstance(long inst);

  public static native boolean Connect(long inst, Port port);

  public static native boolean IsConnected(long inst);

  public static native int GetCurrentStatus(long inst);

  public static native boolean GetLatestEvent(long inst, Event event);

  public static native void SetEventCallback(long inst, IEventCallback cb);

  public static native void RegisterModule(long inst, String moduleId, IModuleDataCallback cb);

  public static native void SetColor(long inst, String zoneId, AnimationColor color);

  public static native void SetGroupColor(long inst, String groupId, AnimationColor color);

  public static native void SetAnimation(long inst, String zoneId, Animation animation, AnimationColor color,
      int delayMs, boolean reversed,
      boolean oneShot);

  public static native void SetGroupAnimation(long inst, String groupId, Animation animation, AnimationColor color,
      int delayMs,
      boolean reversed, boolean oneShot);

  public static native void SetAnimationSequence(long inst, String zoneId, String sequenceId);

  public static native void SetGroupAnimationSequence(long inst, String groupId, String sequenceId);

  public static native void SetBitmap(long inst, String zoneId, String bitmapId, AnimationColor color, boolean setColor,
      boolean oneShot);

  public static native void SetGroupBitmap(long inst, String groupId, String bitmapId, AnimationColor color,
      boolean setColor, boolean oneShot);

  public static native void SetText(long inst, String zoneId, String text, AnimationColor color,
      MatrixTextScrollDirection direction, int delayMs, boolean oneShot);

  public static native void SetGroupText(long inst, String groupId, String text, AnimationColor color,
      MatrixTextScrollDirection direction, int delayMs, boolean oneShot);
}
