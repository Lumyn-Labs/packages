package com.lumynlabs.domain.event;

public class EventCustomInfo {
  public byte type;
  public byte[] data;
}
