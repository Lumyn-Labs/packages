package com.lumynlabs.devices;

import com.lumynlabs.domain.led.LedHandler;

public class ConnectorXAnimate extends ConnectorXBase {
  public final LedHandler leds;

  public ConnectorXAnimate() {
    super();

    leds = new LedHandler(_instance);
  }
}
