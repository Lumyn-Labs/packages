package com.lumynlabs.domain.event;

public class EventFatalError {
  public EventFatalErrorType type;
  public String message;
}
