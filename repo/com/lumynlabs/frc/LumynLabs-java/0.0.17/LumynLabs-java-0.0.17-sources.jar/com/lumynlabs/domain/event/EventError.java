package com.lumynlabs.domain.event;

public class EventError {
  public EventErrorType type;
  public String message;
}
