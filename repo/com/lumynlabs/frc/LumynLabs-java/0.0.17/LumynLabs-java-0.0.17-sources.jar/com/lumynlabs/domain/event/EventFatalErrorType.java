package com.lumynlabs.domain.event;

public enum EventFatalErrorType {
  InitError(0),
  BadConfig(1),
  StartTask(2),
  CreateQueue(3);

  public final int value;

  EventFatalErrorType(int value) {
    this.value = value;
  }
}
