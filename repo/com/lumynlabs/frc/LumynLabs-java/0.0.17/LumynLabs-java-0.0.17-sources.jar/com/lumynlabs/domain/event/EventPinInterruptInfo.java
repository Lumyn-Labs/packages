package com.lumynlabs.domain.event;

public class EventPinInterruptInfo {
  public byte pin;
}
