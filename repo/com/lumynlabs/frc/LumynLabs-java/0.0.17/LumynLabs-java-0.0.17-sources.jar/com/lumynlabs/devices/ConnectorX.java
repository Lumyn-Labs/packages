package com.lumynlabs.devices;

import com.lumynlabs.domain.led.LedHandler;
import com.lumynlabs.domain.module.ModuleHandler;

public class ConnectorX extends ConnectorXBase {
  public final LedHandler leds;
  public final ModuleHandler modules;

  public ConnectorX() {
    super();

    leds = new LedHandler(_instance);
    modules = new ModuleHandler(_instance);
  }
}
