package com.lumynlabs.domain.event;

public enum EventErrorType {
  FileNotFound(0),
  InvalidFile(1),
  EntityNotFound(2),
  DeviceMalfunction(3),
  QueueFull(4),
  LedStrip(5),
  LedMatrix(6),
  InvalidAnimationSequence(7),
  InvalidChannel(8),
  DuplicateID(9),
  InvalidConfigUpload(10);

  public final int value;

  EventErrorType(int value) {
    this.value = value;
  }
}
