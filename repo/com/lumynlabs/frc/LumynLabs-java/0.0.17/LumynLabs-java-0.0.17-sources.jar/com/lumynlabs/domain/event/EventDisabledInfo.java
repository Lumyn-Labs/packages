package com.lumynlabs.domain.event;

public class EventDisabledInfo {
  public EventDisabledCause cause;
}