package com.lumynlabs.domain.led;

// TODO: make this match the firmware
public enum Animation {
  None,
  Fill,
  Blink,
  Breathe,
  RainbowFade,
  SineRoll,
  Chase
}
