package com.lumynlabs.domain.event;

public enum EventDisabledCause {
  NoHeartbeat(0),
  Manual(1),
  EStop(2);

  public final int value;

  EventDisabledCause(int value) {
    this.value = value;
  }
}