package com.lumynlabs.domain.module;

import java.lang.reflect.Field;
import java.nio.ByteBuffer;

import com.lumynlabs.interfaces.IModuleDataCallback;
import com.lumynlabs.jni.LumynJNI;

public class ModuleHandler {
  private long _instance;

  public ModuleHandler(long instance) {
    this._instance = instance;
  }

  public void RegisterModule(String moduleId, IModuleDataCallback cb) {
    LumynJNI.RegisterModule(_instance, moduleId, cb);
  }

  public static <T> void ExtractData(T obj, NewDataInfo data) throws IllegalAccessException {
    int curIndex = 0;

    try {
      for (Field field : obj.getClass().getDeclaredFields()) {
        if (curIndex >= data.len) {
          break;
        }

        if (field.getType().equals(Byte.TYPE)) {
          field.setByte(obj, data.data[curIndex++]);
        } else if (field.getType().equals(Float.TYPE)) {
          var buf = ByteBuffer.wrap(data.data, curIndex, Float.BYTES);
          field.setFloat(obj, buf.getFloat());
          curIndex += Float.BYTES;
        } else if (field.getType().equals(Double.TYPE)) {
          var buf = ByteBuffer.wrap(data.data, curIndex, Double.BYTES);
          field.setFloat(obj, buf.getFloat());
          curIndex += Double.BYTES;
        } else if (field.getType().equals(Short.TYPE)) {
          var buf = ByteBuffer.wrap(data.data, curIndex, Short.BYTES);
          field.setShort(obj, buf.getShort());
          curIndex += Short.BYTES;
        } else if (field.getType().equals(Integer.TYPE)) {
          var buf = ByteBuffer.wrap(data.data, curIndex, Integer.BYTES);
          field.setInt(obj, buf.getInt());
          curIndex += Integer.BYTES;
        } else if (field.getType().equals(Long.TYPE)) {
          var buf = ByteBuffer.wrap(data.data, curIndex, Long.BYTES);
          field.setLong(obj, buf.getLong());
          curIndex += Long.BYTES;
        }
      }
    } catch (Exception e) {
      throw e;
    }
  }
}
