package com.lumynlabs.domain.event;

public class EventDisconnectedInfo {
  public EventConnectionType type;
}
