package com.lumynlabs.domain.event;

public class Event {
  public EventType type;

  // Only 1 will be set depending on the type
  public EventDisabledInfo disabled;
  public EventConnectedInfo connected;
  public EventDisconnectedInfo disconnected;
  public EventError error;
  public EventFatalError fatalError;
  public EventRegisteredEntityInfo registeredEntity;
  public EventCustomInfo custom;
  public EventPinInterruptInfo pinInterrupt;
  public EventHeartBeatInfo heartBeat;
}
