package com.lumynlabs.domain.led;

public enum MatrixTextScrollDirection {
  Left(0),
  Right(1);

  public final int value;

  MatrixTextScrollDirection(int value) {
    this.value = value;
  }
}
