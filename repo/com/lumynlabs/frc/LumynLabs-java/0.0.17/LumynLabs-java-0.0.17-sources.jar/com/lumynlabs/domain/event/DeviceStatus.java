package com.lumynlabs.domain.event;

public enum DeviceStatus {
  Unknown(-1),
  Booting(0),
  Active(1),
  Error(2),
  Fatal(3);

  public final int value;

  DeviceStatus(int value) {
    this.value = value;
  }
}
