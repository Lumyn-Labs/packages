package com.lumynlabs.domain.led;

import com.lumynlabs.jni.LumynJNI;

import edu.wpi.first.units.Measure;
import edu.wpi.first.units.Time;
import edu.wpi.first.units.Units;
import edu.wpi.first.wpilibj.util.Color;

public class LedHandler {
  private long _instance;

  public LedHandler(long instance) {
    this._instance = instance;
  }

  public void SetColor(String zoneId, Color color) {
    LumynJNI.SetColor(_instance, zoneId, FrcColorToAnimationColor(color));
  }

  public void SetGroupColor(String groupId, Color color) {
    LumynJNI.SetGroupColor(_instance, groupId, FrcColorToAnimationColor(color));
  }

  public void SetAnimation(String zoneId, Animation animation, Color color, Measure<Time> delay, boolean reversed,
      boolean oneShot) {
    LumynJNI.SetAnimation(_instance, zoneId, animation, FrcColorToAnimationColor(color),
        (int) delay.in(Units.Milliseconds),
        reversed, oneShot);
  }

  public void SetGroupAnimation(String groupId, Animation animation, Color color, Measure<Time> delay, boolean reversed,
      boolean oneShot) {
    LumynJNI.SetAnimation(_instance, groupId, animation, FrcColorToAnimationColor(color),
        (int) delay.in(Units.Milliseconds),
        reversed, oneShot);
  }

  public void SetAnimationSequence(String zoneId, String sequenceId) {
    LumynJNI.SetAnimationSequence(_instance, zoneId, sequenceId);
  }

  public void SetGroupAnimationSequence(String groupId, String sequenceId) {
    LumynJNI.SetGroupAnimationSequence(_instance, groupId, sequenceId);
  }

  public void SetImageSequence(String zoneId, String sequenceId, Color color, boolean setColor,
      boolean oneShot) {
    LumynJNI.SetBitmap(_instance, zoneId, sequenceId, FrcColorToAnimationColor(color), setColor, oneShot);
  }

  public void SetGroupImageSequence(String groupId, String sequenceid, Color color, boolean setColor,
      boolean oneShot) {
    LumynJNI.SetGroupBitmap(_instance, groupId, sequenceid, FrcColorToAnimationColor(color), setColor, oneShot);
  }

  public void SetMatrixText(String zoneId, String text, Color color, MatrixTextScrollDirection direction,
      Measure<Time> delay,
      boolean oneShot) {
    LumynJNI.SetText(_instance, zoneId, text, FrcColorToAnimationColor(color), direction,
        (int) delay.in(Units.Milliseconds), oneShot);
  }

  public void SetGroupMatrixText(String groupId, String text, Color color, MatrixTextScrollDirection direction,
      Measure<Time> delay,
      boolean oneShot) {
    LumynJNI.SetText(_instance, groupId, text, FrcColorToAnimationColor(color), direction,
        (int) delay.in(Units.Milliseconds), oneShot);
  }

  private static AnimationColor FrcColorToAnimationColor(Color color) {
    var c = new AnimationColor();
    c.r = (byte) (color.red * 255);
    c.g = (byte) (color.green * 255);
    c.b = (byte) (color.blue * 255);

    return c;
  }
}
