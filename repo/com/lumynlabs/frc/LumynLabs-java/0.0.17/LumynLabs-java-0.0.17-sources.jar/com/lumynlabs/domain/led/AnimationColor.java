package com.lumynlabs.domain.led;

public class AnimationColor {
  public byte r;
  public byte g;
  public byte b;
}
