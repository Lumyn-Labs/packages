package com.lumynlabs.domain.event;

public class EventRegisteredEntityInfo {
  public int id;
}
