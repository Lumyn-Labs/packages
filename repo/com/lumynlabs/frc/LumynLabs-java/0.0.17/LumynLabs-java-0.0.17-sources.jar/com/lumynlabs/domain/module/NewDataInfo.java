package com.lumynlabs.domain.module;

public class NewDataInfo {
  public int id;
  public byte[] data;
  public int len;
}
