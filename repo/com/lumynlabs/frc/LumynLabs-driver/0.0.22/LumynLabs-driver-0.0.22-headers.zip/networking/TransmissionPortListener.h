#pragma once

#include <hal/SerialPort.h>

#include "domain/command/Command.h"
#include "domain/response/Response.h"
#include "domain/request/Request.h"
#include "domain/event/Event.h"
#include "domain/module/ModuleData.h"
#include "domain/transmission/Transmission.h"
#include "util/serial/COBSEncoder.h"
#include "util/serial/LumynTP.h"
#include "networking/ILumynTransmissionHandler.h"

#include <iostream>
#include <functional>
#include <condition_variable>

namespace lumyn::internal
{
  class TransmissionPortListener
  {
  public:
    TransmissionPortListener(ILumynTransmissionHandler &handler);
    virtual ~TransmissionPortListener();

    void ConnectToPort(HAL_SerialPort port);
    void SendCommand(const Command::Command &command);

    std::optional<Response::Response> SendRequest(Request::Request &request, int timeoutMs = 10000);

  private:
    void HandleTransmission(const Transmission::Transmission &transmission);
    void ReadDataStream();
    uint32_t GenerateRequestId();
    bool WaitForResponse(int timeoutMs);
    void OnResponse(const Response::Response &response);

    HAL_SerialPort _port;
    std::unique_ptr<PacketSerial> _serial;
    std::unique_ptr<LumynTP> _lumynTp;
    std::thread _readThread;
    std::atomic<bool> _running;
    std::mutex _responseMutex;
    std::condition_variable _responseCondition;
    std::unordered_map<int, Response::Response> _pendingResponses;
    COBSEncoder _encoder;

    ILumynTransmissionHandler &_handler;
    std::unordered_map<int, std::function<void(const Response::Response &)>> _pendingRequests;
  };
} // namespace lumyn::internal