#pragma once

// #include <iostream>
// #include <functional>
// #include "networking/TransmissionPortListener.h"
// #include "ConnectorXInternal.h"
// #include <hal/SerialPort.h>
// #include "led/Animation.h"
// #include <units/time.h>

// namespace lumyn::internal
// {
//   class ConnectorXInternal
//   {
//   public:
//     ConnectorXInternal();
//     ~ConnectorXInternal();

//     void Initialize(HAL_SerialPort);
//     void SetAnimation(lumyn::led::Animation animation, std::string_view zoneID, lumyn::internal::Command::LED::AnimationColor color, units::second_t delay = 0_s, bool reversed = 0, bool oneShot = 0);

//   private:
//     TransmissionPortListener _transmissionPortListener{};
//   };

// #ifdef __cplusplus
//   extern "C"
//   {
// #endif
//     ConnectorXInternal *getConnectorXInternalInstance();
//     void initializeConnectorXinternal(ConnectorXInternal *connectorXInternal, HAL_SerialPort port);
//     void CXISetAnimation(ConnectorXInternal *connectorXInternal, lumyn::led::Animation animation, std::string_view zoneID, lumyn::internal::Command::LED::AnimationColor color, units::second_t delay = 0_s, bool reversed = 0, bool oneShot = 0);

// #ifdef __cplusplus
//   } // extern "C"
// #endif
// }
