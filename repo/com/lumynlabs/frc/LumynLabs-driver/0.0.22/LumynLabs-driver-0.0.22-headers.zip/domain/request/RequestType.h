#pragma once
#include <cinttypes>

namespace lumyn::internal::Request
{
  enum class RequestType : uint8_t
  {
    Handshake = 0,
    Status,
    ProductSKU,
    ProductSerialNumber,
    ConfigHash,
    AssignedId,
    Faults,
    DeviceStatus,
    DeviceData,
    LEDChannelStatus,
    LEDZoneStatus,
    LatestEvent,
    EventFlags,
  };

  enum class HostConnectionSource : uint8_t
  {
    Unknown = 0,
    Studio,
    Roborio,
  };
}; // namespace lumyn::internal::Request