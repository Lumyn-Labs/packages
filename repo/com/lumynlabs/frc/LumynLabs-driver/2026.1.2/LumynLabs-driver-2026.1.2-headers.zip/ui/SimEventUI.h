#pragma once
#ifdef DESKTOP

#include <array>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <sstream>
#include <string>
#include "imgui.h"
#include "device/ConnectorXSimDevice.h"

namespace lumyn::internal
{
  /**
   * Template function for drawing a combo box with clamped index.
   */
  template <size_t N>
  bool DrawClampedCombo(const char *label, int &index, const std::array<const char *, N> &labels)
  {
    bool changed = ImGui::Combo(label, &index, labels.data(), static_cast<int>(labels.size()));
    index = std::clamp(index, 0, static_cast<int>(labels.size()) - 1);
    return changed;
  }

  /**
   * Convert an Eventing::Status to its index in kStatusOptions.
   */
  inline int StatusToIndex(Eventing::Status status)
  {
    const auto &options = ConnectorXSimDevice::kStatusOptions;
    auto it = std::find_if(options.begin(), options.end(),
                           [status](const auto &option)
                           { return option.status == status; });
    return it == options.end() ? 0 : static_cast<int>(std::distance(options.begin(), it));
  }

  /**
   * Convert an index to an Eventing::Status using kStatusOptions.
   */
  inline Eventing::Status StatusFromIndex(int index)
  {
    const auto &options = ConnectorXSimDevice::kStatusOptions;
    if (index < 0 || index >= static_cast<int>(options.size()))
    {
      return Eventing::Status::Unknown;
    }
    return options[static_cast<size_t>(index)].status;
  }

  /**
   * UI state for the event entry form in the simulation.
   */
  struct EventUiState
  {
    EventUiState()
    {
      std::snprintf(errorMessage, sizeof(errorMessage), "Sim error");
      std::snprintf(fatalMessage, sizeof(fatalMessage), "Sim fatal");
      std::fill(std::begin(customBytes), std::end(customBytes), 0);
    }

    int disabledCause = static_cast<int>(Eventing::DisabledCause::NoHeartbeat);
    int connectionType = static_cast<int>(Eventing::ConnectionType::USB);
    int errorType = static_cast<int>(Eventing::ErrorType::FileNotFound);
    int fatalErrorType = static_cast<int>(Eventing::FatalErrorType::InitError);
    int registeredEntityId = 1;
    int pin = 0;
    bool hbEnabled = true;
    bool hbUsb = true;
    bool hbCan = true;
    int hbStatusIndex = StatusToIndex(Eventing::Status::Active);
    int customType = 1;
    int customLen = 0;
    char errorMessage[32];
    char fatalMessage[32];
    unsigned char customBytes[16];
  };

  /**
   * Get the singleton EventUiState instance.
   */
  inline EventUiState &GetEventUiState()
  {
    static EventUiState state;
    return state;
  }

  /**
   * Event entry for combo box selection.
   */
  struct EventEntry
  {
    Eventing::EventType type;
    const char *label;
    void (*draw)(EventUiState &);
    void (*apply)(const EventUiState &, Eventing::Event &);
  };

  /**
   * Event label arrays for various combo boxes.
   */
  constexpr std::array<const char *, 3> kDisabledLabels{"NoHeartbeat", "Manual", "EStop"};
  constexpr std::array<const char *, 5> kConnectionLabels{"USB", "WebUSB", "I2C", "CAN", "UART"};
  constexpr std::array<const char *, 11> kErrorTypeLabels = {
      "FileNotFound", "InvalidFile", "EntityNotFound", "DeviceMalfunction",
      "QueueFull", "LedStrip", "LedMatrix", "InvalidAnimationSequence",
      "InvalidChannel", "DuplicateID", "InvalidConfigUpload"};
  constexpr std::array<const char *, 4> kFatalErrorTypeLabels{"InitError", "BadConfig", "StartTask", "CreateQueue"};

  /**
   * Get array of status labels from kStatusOptions.
   */
  inline const auto &GetStatusLabels()
  {
    static const auto kStatusLabels = []
    {
      std::array<const char *, ConnectorXSimDevice::kStatusOptions.size()> labels{};
      for (size_t i = 0; i < labels.size(); ++i)
      {
        labels[i] = ConnectorXSimDevice::kStatusOptions[i].label;
      }
      return labels;
    }();
    return kStatusLabels;
  }

  // Forward declaration
  const std::array<EventEntry, 12> &EventEntries();

  /**
   * ImGui item getter for event entries.
   */
  inline bool EventItemsGetter(void *, int idx, const char **out_text)
  {
    const auto &entries = EventEntries();
    if (idx < 0 || idx >= static_cast<int>(entries.size()))
    {
      return false;
    }
    *out_text = entries[static_cast<size_t>(idx)].label;
    return true;
  }

  /**
   * Get the array of event entries for the event combo box.
   */
  inline const std::array<EventEntry, 12> &EventEntries()
  {
    static const std::array<EventEntry, 12> entries{{
        {Eventing::EventType::BeginInitialization, "BeginInitialization", nullptr, nullptr},
        {Eventing::EventType::FinishInitialization, "FinishInitialization", nullptr, nullptr},
        {Eventing::EventType::Enabled, "Enabled", nullptr, nullptr},
        {Eventing::EventType::Disabled, "Disabled",
         +[](EventUiState &state)
         {
           DrawClampedCombo("Cause", state.disabledCause, kDisabledLabels);
         },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.disabled.cause = static_cast<Eventing::DisabledCause>(state.disabledCause);
         }},
        {Eventing::EventType::Connected, "Connected",
         +[](EventUiState &state)
         {
           DrawClampedCombo("Conn Type", state.connectionType, kConnectionLabels);
         },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.connected.type = static_cast<Eventing::ConnectionType>(state.connectionType);
         }},
        {Eventing::EventType::Disconnected, "Disconnected",
         +[](EventUiState &state)
         {
           DrawClampedCombo("Conn Type", state.connectionType, kConnectionLabels);
         },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.disconnected.type = static_cast<Eventing::ConnectionType>(state.connectionType);
         }},
        {Eventing::EventType::Error, "Error",
         +[](EventUiState &state)
         {
           ImGui::InputText("Message", state.errorMessage, IM_ARRAYSIZE(state.errorMessage));
           DrawClampedCombo("Error Type", state.errorType, kErrorTypeLabels);
         },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.error.type = static_cast<Eventing::ErrorType>(state.errorType);
           std::snprintf(evt.header.data.error.message,
                         sizeof(evt.header.data.error.message),
                         "%.*s",
                         static_cast<int>(sizeof(evt.header.data.error.message) - 1),
                         state.errorMessage);
         }},
        {Eventing::EventType::FatalError, "FatalError",
         +[](EventUiState &state)
         {
           ImGui::InputText("Message", state.fatalMessage, IM_ARRAYSIZE(state.fatalMessage));
           DrawClampedCombo("Fatal Type", state.fatalErrorType, kFatalErrorTypeLabels);
         },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.fatalError.type = static_cast<Eventing::FatalErrorType>(state.fatalErrorType);
           std::snprintf(evt.header.data.fatalError.message,
                         sizeof(evt.header.data.fatalError.message),
                         "%.*s",
                         static_cast<int>(sizeof(evt.header.data.fatalError.message) - 1),
                         state.fatalMessage);
         }},
        {Eventing::EventType::RegisteredEntity, "RegisteredEntity",
         +[](EventUiState &state)
         { ImGui::InputInt("Entity ID", &state.registeredEntityId); },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.registeredEntity.id = static_cast<uint16_t>(state.registeredEntityId);
         }},
        {Eventing::EventType::Custom, "Custom",
         +[](EventUiState &state)
         {
           ImGui::InputInt("Type", &state.customType);
           ImGui::InputInt("Length", &state.customLen);
           state.customLen = std::clamp(state.customLen, 0, static_cast<int>(sizeof(state.customBytes)));
         },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.custom.type = static_cast<uint8_t>(state.customType);
           evt.header.data.custom.length = static_cast<uint8_t>(state.customLen);
           if (state.customLen > 0)
           {
             std::memcpy(evt.header.data.custom.data, state.customBytes, static_cast<size_t>(state.customLen));
           }
         }},
        {Eventing::EventType::PinInterrupt, "PinInterrupt",
         +[](EventUiState &state)
         { ImGui::InputInt("Pin", &state.pin); },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.pinInterrupt.pin = static_cast<uint8_t>(state.pin);
         }},
        {Eventing::EventType::HeartBeat, "HeartBeat",
         +[](EventUiState &state)
         {
           ImGui::Checkbox("Enabled", &state.hbEnabled);
           ImGui::Checkbox("USB Connected", &state.hbUsb);
           ImGui::Checkbox("CAN OK", &state.hbCan);
           DrawClampedCombo("Status##HeartbeatEvent", state.hbStatusIndex, GetStatusLabels());
         },
         +[](const EventUiState &state, Eventing::Event &evt)
         {
           evt.header.data.heartBeat.status = StatusFromIndex(state.hbStatusIndex);
           evt.header.data.heartBeat.enabled = static_cast<uint8_t>(state.hbEnabled);
           evt.header.data.heartBeat.connectedUSB = static_cast<uint8_t>(state.hbUsb);
           evt.header.data.heartBeat.canOK = static_cast<uint8_t>(state.hbCan);
         }},
    }};
    return entries;
  }

  /**
   * Safely get a label from an array with bounds checking.
   */
  template <size_t N>
  const char *SafeLabel(const std::array<const char *, N> &labels, size_t idx)
  {
    return idx < labels.size() ? labels[idx] : "Unknown";
  }

  /**
   * Get the label for a given event type.
   */
  inline const char *LabelForEventType(Eventing::EventType type)
  {
    const auto &entries = EventEntries();
    for (const auto &entry : entries)
    {
      if (entry.type == type)
      {
        return entry.label;
      }
    }
    return "Unknown";
  }

  /**
   * Generate a human-readable summary of an event.
   */
  inline std::string DescribeEventSummary(const Eventing::Event &evt)
  {
    std::ostringstream ss;
    switch (evt.header.type)
    {
    case Eventing::EventType::Disabled:
    {
      size_t idx = static_cast<size_t>(evt.header.data.disabled.cause);
      ss << "Cause: " << SafeLabel(kDisabledLabels, idx);
      break;
    }
    case Eventing::EventType::Connected:
    {
      size_t idx = static_cast<size_t>(evt.header.data.connected.type);
      ss << "Type: " << SafeLabel(kConnectionLabels, idx);
      break;
    }
    case Eventing::EventType::Disconnected:
    {
      size_t idx = static_cast<size_t>(evt.header.data.disconnected.type);
      ss << "Type: " << SafeLabel(kConnectionLabels, idx);
      break;
    }
    case Eventing::EventType::Error:
    {
      size_t idx = static_cast<size_t>(evt.header.data.error.type);
      ss << SafeLabel(kErrorTypeLabels, idx) << " - " << evt.header.data.error.message;
      break;
    }
    case Eventing::EventType::FatalError:
    {
      size_t idx = static_cast<size_t>(evt.header.data.fatalError.type);
      ss << SafeLabel(kFatalErrorTypeLabels, idx) << " - " << evt.header.data.fatalError.message;
      break;
    }
    case Eventing::EventType::RegisteredEntity:
    {
      ss << "Entity ID: " << evt.header.data.registeredEntity.id;
      break;
    }
    case Eventing::EventType::Custom:
    {
      ss << "Type " << static_cast<int>(evt.header.data.custom.type)
         << ", Length " << static_cast<int>(evt.header.data.custom.length);
      break;
    }
    case Eventing::EventType::PinInterrupt:
    {
      ss << "Pin: " << static_cast<int>(evt.header.data.pinInterrupt.pin);
      break;
    }
    case Eventing::EventType::HeartBeat:
    {
      ss << "Status: " << ConnectorXSimDevice::StatusToString(evt.header.data.heartBeat.status)
         << ", Enabled: " << (evt.header.data.heartBeat.enabled ? "Yes" : "No")
         << ", USB: " << (evt.header.data.heartBeat.connectedUSB ? "Yes" : "No")
         << ", CAN: " << (evt.header.data.heartBeat.canOK ? "Yes" : "No");
      break;
    }
    default:
      break;
    }

    if (evt.hasExtraMessage())
    {
      const uint8_t *extraData = evt.getExtraMessage();
      uint16_t extraLen = evt.getExtraMessageLength();
      if (extraData && extraLen > 0)
      {
        // Create a null-terminated string from the raw data
        std::string extraStr(reinterpret_cast<const char *>(extraData), extraLen);
        if (!extraStr.empty())
        {
          if (ss.tellp() > 0)
          {
            ss << " | ";
          }
          ss << "Extra: " << extraStr;
        }
      }
    }

    auto summary = ss.str();
    if (summary.empty())
    {
      summary = "No additional data";
    }
    return summary;
  }

} // namespace lumyn::internal

#endif // DESKTOP
