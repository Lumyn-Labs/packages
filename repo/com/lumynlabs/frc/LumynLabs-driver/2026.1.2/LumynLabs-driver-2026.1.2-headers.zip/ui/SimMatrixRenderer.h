#pragma once
#ifdef DESKTOP

#include <vector>
#include <cstdint>
#include <cmath>
#include <algorithm>
#include "lumyn/domain/Color.h"
#include "lumyn/domain/command/led/LEDCommand.h"
#include "device/ConnectorXSimDevice.h"
#include "ui/MatrixFont.h"
#include "ui/MatrixTextFontUtils.h"
#include "ui/SimGFXCanvas.h"
#include "ui/SimMatrixTextFonts.h"
#include "ui/SimBitmapLoader.h"

namespace lumyn::internal
{
  /**
   * Matrix orientation bit flags (matching firmware definitions).
   */
  constexpr uint8_t kMatrixOrientationBottom = 0x01;
  constexpr uint8_t kMatrixOrientationRight = 0x02;
  constexpr uint8_t kMatrixOrientationColumns = 0x04;
  constexpr uint8_t kMatrixOrientationZigzag = 0x08;

  /**
   * Apply matrix orientation transformation to a buffer of colors.
   * Transforms pixel positions based on physical LED matrix wiring.
   */
  inline void ApplyMatrixOrientation(std::vector<lumyn::internal::domain::Color> &buffer,
                                     uint16_t rows, uint16_t cols, uint8_t orientation)
  {
    if (rows == 0 || cols == 0)
    {
      return;
    }

    std::vector<lumyn::internal::domain::Color> copy = buffer;
    for (uint16_t row = 0; row < rows; ++row)
    {
      for (uint16_t col = 0; col < cols; ++col)
      {
        uint16_t srcRow = row;
        uint16_t srcCol = col;
        if (orientation & kMatrixOrientationBottom)
        {
          srcRow = rows - 1 - srcRow;
        }
        if (orientation & kMatrixOrientationRight)
        {
          srcCol = cols - 1 - srcCol;
        }
        if (orientation & kMatrixOrientationColumns)
        {
          std::swap(srcRow, srcCol);
          if (srcRow >= rows)
            srcRow = rows - 1;
          if (srcCol >= cols)
            srcCol = cols - 1;
        }
        if ((orientation & kMatrixOrientationZigzag) != 0 && (row % 2 == 1))
        {
          srcCol = cols - 1 - srcCol;
        }

        if (srcRow < rows && srcCol < cols)
        {
          buffer[row * cols + col] = copy[srcRow * cols + srcCol];
        }
      }
    }
  }

  /**
   * Apply a tint color to a source color.
   */
  inline lumyn::internal::domain::Color TintColor(const lumyn::internal::domain::Color &src,
                                                  const lumyn::internal::domain::Color &tint,
                                                  bool applyTint)
  {
    if (!applyTint)
    {
      return src;
    }
    return {
        static_cast<uint8_t>((src.r * tint.r) / 255),
        static_cast<uint8_t>((src.g * tint.g) / 255),
        static_cast<uint8_t>((src.b * tint.b) / 255)};
  }

  /**
   * Calculate the actual pixel width of text when rendered with a GFX font.
   * This uses the font glyph xAdvance values for accurate width calculation.
   * For proportional fonts, this will differ from the estimated character width * length.
   * 
   * @param text The text to measure
   * @param textLen The length of the text
   * @param font The font enum value
   * @return The actual pixel width of the rendered text
   */
  inline uint16_t CalculateActualTextWidth(const char *text, size_t textLen, Command::LED::MatrixTextFont fontEnum)
  {
    const GFXfont *font = ui::GetMatrixTextFont(fontEnum);
    if (!font)
    {
      // Builtin font: 6 pixels per character (5 + 1 spacing)
      return static_cast<uint16_t>(textLen * 6);
    }

    uint16_t totalWidth = 0;
    uint16_t first = pgm_read_word(&font->first);
    uint16_t last = pgm_read_word(&font->last);

    for (size_t i = 0; i < textLen; ++i)
    {
      uint8_t c = static_cast<uint8_t>(text[i]);
      if (c >= first && c <= last)
      {
        GFXglyph *glyph = &((GFXglyph *)pgm_read_ptr(&font->glyph))[c - first];
        totalWidth += pgm_read_byte(&glyph->xAdvance);
      }
    }
    return totalWidth;
  }

  /**
   * Render text to the matrix buffer using Adafruit GFX fonts.
   * This uses SimGFXCanvas for proper font rendering with parity to firmware.
   */
  inline void RenderMatrixTextWithGFXFonts(std::vector<lumyn::internal::domain::Color> &buffer,
                                           uint16_t rows, uint16_t cols,
                                           int16_t cursorX, int16_t cursorY,
                                           const char *text, size_t textLen,
                                           const ConnectorXSimDevice::ZoneState &zs,
                                           bool rotate180,
                                           bool reverseCharOrder = false)
  {
    // Create a temporary RGBA buffer for SimGFXCanvas
    std::vector<uint32_t> tempBuffer(rows * cols, 0);

    // Create canvas with matrix dimensions
    ui::SimGFXCanvas<uint32_t> canvas(tempBuffer.data(), cols, rows);

    // Set rotation (firmware uses rotation 2 = 180 degrees for text)
    if (rotate180)
    {
      canvas.setRotation(2);
    }

    // Get the font for the current text settings
    const GFXfont *font = ui::GetMatrixTextFont(zs.lastMatrixText.font);
    canvas.setFont(font);
    canvas.setTextSize(1);
    canvas.setTextWrap(false);

    // Set text color as RGBA (we'll extract from the zs.lastMatrixText.color)
    uint32_t textColor = (static_cast<uint32_t>(zs.lastMatrixText.color.r) << 0) |
                         (static_cast<uint32_t>(zs.lastMatrixText.color.g) << 8) |
                         (static_cast<uint32_t>(zs.lastMatrixText.color.b) << 16) |
                         0xFF000000;
    canvas.setTextColor(textColor);

    // Position cursor and print text
    canvas.setCursor(cursorX, cursorY);
    if (reverseCharOrder)
    {
      // For RIGHT scroll, print characters in reverse order so text is readable
      // when entering from the left side of the screen (matches firmware behavior)
      for (int i = static_cast<int>(textLen) - 1; i >= 0; i--)
      {
        canvas.print(static_cast<char>(text[i]));
      }
    }
    else
    {
      // For LEFT scroll, print normally left to right
      for (size_t i = 0; i < textLen; ++i)
      {
        canvas.print(static_cast<char>(text[i]));
      }
    }

    // Copy rendered pixels to the output buffer
    for (uint16_t y = 0; y < rows; ++y)
    {
      for (uint16_t x = 0; x < cols; ++x)
      {
        uint32_t pixel = tempBuffer[y * cols + x];
        // Only copy non-zero pixels (where text was drawn)
        if (pixel != 0)
        {
          buffer[y * cols + x] = {
              static_cast<uint8_t>((pixel >> 0) & 0xFF),
              static_cast<uint8_t>((pixel >> 8) & 0xFF),
              static_cast<uint8_t>((pixel >> 16) & 0xFF)};
        }
      }
    }
  }

  /**
   * Legacy DrawMatrixGlyph for backwards compatibility (uses builtin 5x7 font only).
   */
  inline void DrawMatrixGlyph(std::vector<lumyn::internal::domain::Color> &buffer,
                              uint16_t rows, uint16_t cols,
                              int baseX, int baseY, char c,
                              const ConnectorXSimDevice::ZoneState &zs,
                              bool rotate180)
  {
    const uint8_t *glyph = lumyn::internal::ui::MatrixFont::FontForChar(c);
    auto plot = [&](int x, int y)
    {
      if (rotate180)
      {
        x = static_cast<int>(cols) - 1 - x;
        y = static_cast<int>(rows) - 1 - y;
      }
      if (x < 0 || x >= cols || y < 0 || y >= rows)
      {
        return;
      }
      buffer[static_cast<size_t>(y) * cols + static_cast<size_t>(x)] = {
          zs.lastMatrixText.color.r,
          zs.lastMatrixText.color.g,
          zs.lastMatrixText.color.b};
    };

    constexpr int kGlyphColumns = lumyn::internal::ui::kMatrixFontWidth;
    constexpr int kGlyphRows = lumyn::internal::ui::kMatrixFontHeight;
    for (int column = 0; column < kGlyphColumns + 1; ++column)
    {
      uint8_t line = column < kGlyphColumns ? glyph[column] : 0;
      for (int bit = 0; bit < kGlyphRows; ++bit)
      {
        if (line & 0x1)
        {
          plot(baseX + column, baseY + bit);
        }
        line >>= 1;
      }
    }
  }

  /**
   * Create a Color from an AnimationColor command structure.
   */
  inline lumyn::internal::domain::Color MakeColor(const Command::LED::AnimationColor &color)
  {
    return {color.r, color.g, color.b};
  }

  /**
   * Font option for UI combo box.
   */
  struct MatrixTextFontOption
  {
    Command::LED::MatrixTextFont font;
    const char *label;
  };

  /**
   * Available matrix text fonts.
   */
  static constexpr MatrixTextFontOption kMatrixTextFontOptions[] = {
      {Command::LED::MatrixTextFont::BUILTIN, "Built-in"},
      {Command::LED::MatrixTextFont::TINY_3X3, "Tiny 3x3"},
      {Command::LED::MatrixTextFont::PICOPIXEL, "Picopixel"},
      {Command::LED::MatrixTextFont::TOM_THUMB, "Tom Thumb"},
      {Command::LED::MatrixTextFont::ORG_01, "Org_01"},
      {Command::LED::MatrixTextFont::FREE_MONO_9, "FreeMono 9"},
      {Command::LED::MatrixTextFont::FREE_MONO_BOLD_9, "FreeMono Bold 9"},
      {Command::LED::MatrixTextFont::FREE_SANS_9, "FreeSans 9"},
      {Command::LED::MatrixTextFont::FREE_SANS_BOLD_9, "FreeSans Bold 9"},
      {Command::LED::MatrixTextFont::FREE_SERIF_9, "FreeSerif 9"},
      {Command::LED::MatrixTextFont::FREE_SERIF_BOLD_9, "FreeSerif Bold 9"},
      {Command::LED::MatrixTextFont::FREE_MONO_12, "FreeMono 12"},
      {Command::LED::MatrixTextFont::FREE_MONO_BOLD_12, "FreeMono Bold 12"},
      {Command::LED::MatrixTextFont::FREE_SANS_12, "FreeSans 12"},
      {Command::LED::MatrixTextFont::FREE_SANS_BOLD_12, "FreeSans Bold 12"},
      {Command::LED::MatrixTextFont::FREE_SERIF_12, "FreeSerif 12"},
      {Command::LED::MatrixTextFont::FREE_SERIF_BOLD_12, "FreeSerif Bold 12"},
      {Command::LED::MatrixTextFont::FREE_MONO_18, "FreeMono 18"},
      {Command::LED::MatrixTextFont::FREE_MONO_BOLD_18, "FreeMono Bold 18"},
      {Command::LED::MatrixTextFont::FREE_SANS_18, "FreeSans 18"},
      {Command::LED::MatrixTextFont::FREE_SANS_BOLD_18, "FreeSans Bold 18"},
      {Command::LED::MatrixTextFont::FREE_SERIF_18, "FreeSerif 18"},
      {Command::LED::MatrixTextFont::FREE_SERIF_BOLD_18, "FreeSerif Bold 18"},
      {Command::LED::MatrixTextFont::FREE_MONO_24, "FreeMono 24"},
      {Command::LED::MatrixTextFont::FREE_MONO_BOLD_24, "FreeMono Bold 24"},
      {Command::LED::MatrixTextFont::FREE_SANS_24, "FreeSans 24"},
      {Command::LED::MatrixTextFont::FREE_SANS_BOLD_24, "FreeSans Bold 24"},
      {Command::LED::MatrixTextFont::FREE_SERIF_24, "FreeSerif 24"},
      {Command::LED::MatrixTextFont::FREE_SERIF_BOLD_24, "FreeSerif Bold 24"},
  };

  static constexpr int kMatrixTextFontOptionCount =
      static_cast<int>(sizeof(kMatrixTextFontOptions) / sizeof(kMatrixTextFontOptions[0]));

  /**
   * ImGui item getter callback for font options.
   */
  inline bool MatrixTextFontItemsGetter(void *, int index, const char **outText)
  {
    if (index < 0 || index >= kMatrixTextFontOptionCount)
    {
      return false;
    }
    *outText = kMatrixTextFontOptions[index].label;
    return true;
  }

  /**
   * Fill matrix buffer with rendered text.
   */
  inline void FillMatrixText(std::vector<lumyn::internal::domain::Color> &buffer,
                             uint16_t rows, uint16_t cols,
                             const ConnectorXSimDevice::ZoneState &zs)
  {
    if (rows == 0 || cols == 0)
    {
      return;
    }

    const auto &text = zs.lastMatrixText;
    if (text.length == 0)
    {
      lumyn::internal::domain::Color fillColor = text.flags.showBackground ? MakeColor(text.bgColor)
                                                                           : lumyn::internal::domain::Color{0, 0, 0};
      std::fill(buffer.begin(), buffer.end(), fillColor);
      return;
    }

    // Fill background
    lumyn::internal::domain::Color bgColor = MakeColor(text.bgColor);
    if (text.flags.showBackground)
    {
      std::fill(buffer.begin(), buffer.end(), bgColor);
    }
    else
    {
      std::fill(buffer.begin(), buffer.end(), lumyn::internal::domain::Color{0, 0, 0});
    }

    // Get font metrics - now using proper GFX font widths and heights
    uint8_t charWidth = ui::GetMatrixTextFontCharWidth(text.font);
    uint8_t fontHeight = ui::GetMatrixTextFontHeight(text.font);
    const GFXfont *font = ui::GetMatrixTextFont(text.font);

    if (charWidth == 0)
    {
      charWidth = 6; // Fallback for builtin font
    }

    // Calculate vertical position
    // For GFX fonts, cursor Y is at the baseline, not top-left
    // For builtin font (nullptr), cursor Y is at top-left
    int16_t yPos;
    if (font != nullptr)
    {
      // GFX font: cursor is at baseline, so we position at (matrixHeight + fontHeight) / 2
      yPos = static_cast<int16_t>((rows + fontHeight) / 2) + static_cast<int16_t>(text.yOffset);
    }
    else
    {
      // Builtin 5x7 font: cursor is at top-left
      yPos = static_cast<int16_t>(rows) / 2 - static_cast<int16_t>(fontHeight / 2) +
             static_cast<int16_t>(text.yOffset);
    }

    // Static text (no scrolling)
    if (text.flags.noScroll)
    {
      // Calculate actual text width from font glyphs for accurate alignment
      int16_t textWidth = static_cast<int16_t>(CalculateActualTextWidth(
          reinterpret_cast<const char *>(text.text), text.length, text.font));
      int16_t xStart = 0;
      switch (text.align)
      {
      case Command::LED::MatrixTextAlign::CENTER:
        xStart = static_cast<int16_t>((cols - textWidth) / 2);
        break;
      case Command::LED::MatrixTextAlign::RIGHT:
        xStart = static_cast<int16_t>(cols - textWidth);
        break;
      case Command::LED::MatrixTextAlign::LEFT:
      default:
        xStart = 0;
        break;
      }

      // Use the new GFX font rendering
      RenderMatrixTextWithGFXFonts(buffer, rows, cols, xStart, yPos,
                                   reinterpret_cast<const char *>(text.text), text.length, zs, false);
      return;
    }

    // Scrolling text
    // Calculate actual text width from font glyphs for accurate scroll calculations
    float matrixWidth = static_cast<float>(cols);
    float textPixelWidth = static_cast<float>(CalculateActualTextWidth(
        reinterpret_cast<const char *>(text.text), text.length, text.font));
    float totalDistance = matrixWidth + textPixelWidth;
    if (totalDistance <= 0.0f)
    {
      totalDistance = std::max(matrixWidth, 1.0f);
    }

    float stepSize = text.flags.smoothScroll ? 1.0f : static_cast<float>(charWidth);
    if (stepSize <= 0.0f)
    {
      stepSize = 1.0f;
    }

    float delayMs = static_cast<float>(std::max<uint16_t>(1u, text.delay));
    float normalizedSteps = delayMs > 0.0f ? (zs.timeMs / delayMs) : 0.0f;
    float rawOffset = normalizedSteps * stepSize;

    if (text.oneShot)
    {
      float stepsPerDirection = totalDistance / stepSize;
      if (stepsPerDirection < 1.0f)
      {
        stepsPerDirection = 1.0f;
      }
      float stepsPerCycle = stepsPerDirection * (text.flags.pingPong ? 2.0f : 1.0f);
      float maxOffset = stepsPerCycle * stepSize;
      rawOffset = std::min(rawOffset, maxOffset);
    }

    float scrollOffset = rawOffset;
    if (text.flags.pingPong)
    {
      float cycleDistance = 2.0f * totalDistance;
      if (cycleDistance <= 0.0f)
      {
        cycleDistance = totalDistance;
      }
      if (cycleDistance <= 0.0f)
      {
        cycleDistance = 1.0f;
      }
      float wrapped = std::fmod(rawOffset, cycleDistance);
      if (wrapped < 0.0f)
      {
        wrapped += cycleDistance;
      }
      if (wrapped >= totalDistance)
      {
        scrollOffset = cycleDistance - wrapped;
      }
      else
      {
        scrollOffset = wrapped;
      }
    }
    else if (!text.oneShot)
    {
      if (totalDistance > 0.0f)
      {
        scrollOffset = std::fmod(rawOffset, totalDistance);
        if (scrollOffset < 0.0f)
        {
          scrollOffset += totalDistance;
        }
      }
    }
    else
    {
      scrollOffset = std::min(scrollOffset, totalDistance);
    }

    int16_t xPos = 0;
    if (text.dir == Command::LED::MatrixTextScrollDirection::LEFT)
    {
      xPos = static_cast<int16_t>(matrixWidth - scrollOffset);
    }
    else
    {
      xPos = static_cast<int16_t>(scrollOffset - textPixelWidth);
    }

    // Use the new GFX font rendering
    // For RIGHT scroll, reverse character order to match firmware behavior
    bool reverseCharOrder = (text.dir == Command::LED::MatrixTextScrollDirection::RIGHT);
    RenderMatrixTextWithGFXFonts(buffer, rows, cols, xPos, yPos,
                                 reinterpret_cast<const char *>(text.text), text.length, zs, false, reverseCharOrder);
  }

  /**
   * Fill matrix buffer with bitmap from configuration.
   */
  inline void FillMatrixBitmap(std::vector<lumyn::internal::domain::Color> &buffer,
                               uint16_t rows, uint16_t cols,
                               const ConnectorXSimDevice::ZoneState &zs,
                               ConnectorXSimDevice &simDev)
  {
    if (rows == 0 || cols == 0)
      return;
    auto bmpInfo = simDev.GetBitmapInfo(zs.lastBitmap.bitmapId);
    if (!bmpInfo)
      return;

    const auto *sequence = BitmapLoader::LoadBitmap(zs.lastBitmap.bitmapId, *bmpInfo);
    if (!sequence || sequence->frames.empty())
      return;

    bool animated = bmpInfo->type == lumyn::internal::Configuration::BitmapType::Animated;
    float delayMs = 1.0f;
    if (animated)
    {
      delayMs = static_cast<float>(bmpInfo->frameDelay.value_or(100u));
      if (delayMs <= 0.0f)
        delayMs = 1.0f;
    }

    size_t frameCount = sequence->frames.size();
    size_t frameIdx = 0;
    if (animated && frameCount > 1)
    {
      frameIdx = static_cast<size_t>(static_cast<int>(zs.timeMs / delayMs) % static_cast<int>(frameCount));
    }
    if (frameIdx >= frameCount)
      frameIdx = 0;

    const auto &frame = sequence->frames[frameIdx];
    if (frame.width == 0 || frame.height == 0)
      return;

    float scaleX = static_cast<float>(frame.width) / cols;
    float scaleY = static_cast<float>(frame.height) / rows;
    scaleX = scaleX == 0.0f ? 1.0f : scaleX;
    scaleY = scaleY == 0.0f ? 1.0f : scaleY;

    lumyn::internal::domain::Color tint{zs.lastBitmap.color.r, zs.lastBitmap.color.g, zs.lastBitmap.color.b};
    bool applyTint = zs.lastBitmap.setColor != 0;

    for (uint16_t row = 0; row < rows; ++row)
    {
      for (uint16_t col = 0; col < cols; ++col)
      {
        int srcX = std::min(frame.width - 1, static_cast<int>((col + 0.5f) * scaleX));
        int srcY = std::min(frame.height - 1, static_cast<int>((row + 0.5f) * scaleY));
        if (srcX < 0)
          srcX = 0;
        if (srcY < 0)
          srcY = 0;
        size_t pixelIdx = static_cast<size_t>(srcY * frame.width + srcX) * 3;
        if (pixelIdx + 2 >= frame.pixels.size())
          continue;
        lumyn::internal::domain::Color base{
            frame.pixels[pixelIdx + 0],
            frame.pixels[pixelIdx + 1],
            frame.pixels[pixelIdx + 2]};
        buffer[row * cols + col] = TintColor(base, tint, applyTint);
      }
    }
  }

} // namespace lumyn::internal

#endif // DESKTOP
