// SPDX-License-Identifier: LGPL-2.1-or-later
// Font mapping for simulation - mirrors firmware's MatrixTextFonts.h
#pragma once

#include "lumyn/domain/command/led/LEDCommand.h"
#include "gfxfont.h"

// Include all available fonts from Adafruit GFX (downloaded via Gradle)
#include "Fonts/Org_01.h"
#include "Fonts/Picopixel.h"
#include "Fonts/Tiny3x3a2pt7b.h"
#include "Fonts/TomThumb.h"

// 9pt fonts
#include "Fonts/FreeMono9pt7b.h"
#include "Fonts/FreeMonoBold9pt7b.h"
#include "Fonts/FreeSans9pt7b.h"
#include "Fonts/FreeSansBold9pt7b.h"
#include "Fonts/FreeSerif9pt7b.h"
#include "Fonts/FreeSerifBold9pt7b.h"

// 12pt fonts
#include "Fonts/FreeMono12pt7b.h"
#include "Fonts/FreeMonoBold12pt7b.h"
#include "Fonts/FreeSans12pt7b.h"
#include "Fonts/FreeSansBold12pt7b.h"
#include "Fonts/FreeSerif12pt7b.h"
#include "Fonts/FreeSerifBold12pt7b.h"

// 18pt fonts
#include "Fonts/FreeMono18pt7b.h"
#include "Fonts/FreeMonoBold18pt7b.h"
#include "Fonts/FreeSans18pt7b.h"
#include "Fonts/FreeSansBold18pt7b.h"
#include "Fonts/FreeSerif18pt7b.h"
#include "Fonts/FreeSerifBold18pt7b.h"

// 24pt fonts
#include "Fonts/FreeMono24pt7b.h"
#include "Fonts/FreeMonoBold24pt7b.h"
#include "Fonts/FreeSans24pt7b.h"
#include "Fonts/FreeSansBold24pt7b.h"
#include "Fonts/FreeSerif24pt7b.h"
#include "Fonts/FreeSerifBold24pt7b.h"

namespace lumyn::internal::ui {

using Command::LED::MatrixTextFont;

/**
 * @brief Get the GFXfont pointer for a given MatrixTextFont enum value
 * @param font The font enum value
 * @return Pointer to the GFXfont, or nullptr for BUILTIN (uses default 5x7)
 * 
 * This mirrors the firmware's MatrixTextFonts::getFont() function for
 * exact parity between simulation and actual hardware rendering.
 */
inline const GFXfont* GetMatrixTextFont(MatrixTextFont font) {
    switch (font) {
    case MatrixTextFont::BUILTIN:
        return nullptr; // Use built-in 5x7 font

    // Tiny fonts - great for small LED matrices
    case MatrixTextFont::TINY_3X3:
        return &Tiny3x3a2pt7b;
    case MatrixTextFont::PICOPIXEL:
        return &Picopixel;
    case MatrixTextFont::TOM_THUMB:
        return &TomThumb;
    case MatrixTextFont::ORG_01:
        return &Org_01;

    // 9pt fonts
    case MatrixTextFont::FREE_MONO_9:
        return &FreeMono9pt7b;
    case MatrixTextFont::FREE_MONO_BOLD_9:
        return &FreeMonoBold9pt7b;
    case MatrixTextFont::FREE_SANS_9:
        return &FreeSans9pt7b;
    case MatrixTextFont::FREE_SANS_BOLD_9:
        return &FreeSansBold9pt7b;
    case MatrixTextFont::FREE_SERIF_9:
        return &FreeSerif9pt7b;
    case MatrixTextFont::FREE_SERIF_BOLD_9:
        return &FreeSerifBold9pt7b;

    // 12pt fonts
    case MatrixTextFont::FREE_MONO_12:
        return &FreeMono12pt7b;
    case MatrixTextFont::FREE_MONO_BOLD_12:
        return &FreeMonoBold12pt7b;
    case MatrixTextFont::FREE_SANS_12:
        return &FreeSans12pt7b;
    case MatrixTextFont::FREE_SANS_BOLD_12:
        return &FreeSansBold12pt7b;
    case MatrixTextFont::FREE_SERIF_12:
        return &FreeSerif12pt7b;
    case MatrixTextFont::FREE_SERIF_BOLD_12:
        return &FreeSerifBold12pt7b;

    // 18pt fonts
    case MatrixTextFont::FREE_MONO_18:
        return &FreeMono18pt7b;
    case MatrixTextFont::FREE_MONO_BOLD_18:
        return &FreeMonoBold18pt7b;
    case MatrixTextFont::FREE_SANS_18:
        return &FreeSans18pt7b;
    case MatrixTextFont::FREE_SANS_BOLD_18:
        return &FreeSansBold18pt7b;
    case MatrixTextFont::FREE_SERIF_18:
        return &FreeSerif18pt7b;
    case MatrixTextFont::FREE_SERIF_BOLD_18:
        return &FreeSerifBold18pt7b;

    // 24pt fonts
    case MatrixTextFont::FREE_MONO_24:
        return &FreeMono24pt7b;
    case MatrixTextFont::FREE_MONO_BOLD_24:
        return &FreeMonoBold24pt7b;
    case MatrixTextFont::FREE_SANS_24:
        return &FreeSans24pt7b;
    case MatrixTextFont::FREE_SANS_BOLD_24:
        return &FreeSansBold24pt7b;
    case MatrixTextFont::FREE_SERIF_24:
        return &FreeSerif24pt7b;
    case MatrixTextFont::FREE_SERIF_BOLD_24:
        return &FreeSerifBold24pt7b;

    default:
        return nullptr; // Fallback to built-in
    }
}

/**
 * @brief Get the approximate font height for vertical positioning
 * @param font The font enum value
 * @return Approximate font height in pixels
 * 
 * These values match the firmware's MatrixTextFonts::getFontHeight().
 */
inline uint8_t GetMatrixTextFontHeight(MatrixTextFont font) {
    switch (font) {
    case MatrixTextFont::BUILTIN:
        return 7;
    case MatrixTextFont::TINY_3X3:
        return 3;
    case MatrixTextFont::PICOPIXEL:
        return 5;
    case MatrixTextFont::TOM_THUMB:
        return 5;
    case MatrixTextFont::ORG_01:
        return 6;

    // 9pt fonts
    case MatrixTextFont::FREE_MONO_9:
    case MatrixTextFont::FREE_MONO_BOLD_9:
    case MatrixTextFont::FREE_SANS_9:
    case MatrixTextFont::FREE_SANS_BOLD_9:
    case MatrixTextFont::FREE_SERIF_9:
    case MatrixTextFont::FREE_SERIF_BOLD_9:
        return 12;

    // 12pt fonts
    case MatrixTextFont::FREE_MONO_12:
    case MatrixTextFont::FREE_MONO_BOLD_12:
    case MatrixTextFont::FREE_SANS_12:
    case MatrixTextFont::FREE_SANS_BOLD_12:
    case MatrixTextFont::FREE_SERIF_12:
    case MatrixTextFont::FREE_SERIF_BOLD_12:
        return 16;

    // 18pt fonts
    case MatrixTextFont::FREE_MONO_18:
    case MatrixTextFont::FREE_MONO_BOLD_18:
    case MatrixTextFont::FREE_SANS_18:
    case MatrixTextFont::FREE_SANS_BOLD_18:
    case MatrixTextFont::FREE_SERIF_18:
    case MatrixTextFont::FREE_SERIF_BOLD_18:
        return 24;

    // 24pt fonts
    case MatrixTextFont::FREE_MONO_24:
    case MatrixTextFont::FREE_MONO_BOLD_24:
    case MatrixTextFont::FREE_SANS_24:
    case MatrixTextFont::FREE_SANS_BOLD_24:
    case MatrixTextFont::FREE_SERIF_24:
    case MatrixTextFont::FREE_SERIF_BOLD_24:
        return 32;

    default:
        return 7;
    }
}

} // namespace lumyn::internal::ui
