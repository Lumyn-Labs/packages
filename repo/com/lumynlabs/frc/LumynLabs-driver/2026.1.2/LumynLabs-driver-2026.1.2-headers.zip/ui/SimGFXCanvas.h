// SPDX-License-Identifier: LGPL-2.1-or-later
// Software canvas for rendering text using Adafruit GFX fonts
// This provides simulation parity with firmware's FastLED_NeoMatrix

#pragma once

#include <cstdint>
#include <cstring>
#include <algorithm>
#include "gfxfont.h"

namespace lumyn::internal::ui {

/**
 * A software canvas that renders using Adafruit GFX font data.
 * Provides the same text rendering API as Adafruit_GFX for simulation parity.
 * 
 * Template parameters:
 *   PixelType - The pixel type for the buffer (e.g., uint32_t for RGBA)
 */
template<typename PixelType>
class SimGFXCanvas {
public:
    SimGFXCanvas(PixelType* buffer, int16_t width, int16_t height)
        : m_buffer(buffer)
        , m_width(width)
        , m_height(height)
        , m_cursorX(0)
        , m_cursorY(0)
        , m_textColor(0xFFFFFFFF)
        , m_bgColor(0)
        , m_font(nullptr)
        , m_textSize(1)
        , m_wrap(true)
        , m_rotation(0)
    {
    }

    // Canvas dimensions
    int16_t width() const { return m_width; }
    int16_t height() const { return m_height; }

    // Clear the canvas
    void fillScreen(PixelType color) {
        for (int i = 0; i < m_width * m_height; ++i) {
            m_buffer[i] = color;
        }
    }

    // Set a single pixel (with rotation support)
    void drawPixel(int16_t x, int16_t y, PixelType color) {
        // Apply rotation
        int16_t tx, ty;
        switch (m_rotation) {
            case 1:  // 90 degrees CW
                tx = m_width - 1 - y;
                ty = x;
                break;
            case 2:  // 180 degrees
                tx = m_width - 1 - x;
                ty = m_height - 1 - y;
                break;
            case 3:  // 270 degrees CW
                tx = y;
                ty = m_height - 1 - x;
                break;
            default: // 0 degrees
                tx = x;
                ty = y;
                break;
        }

        if (tx >= 0 && tx < m_width && ty >= 0 && ty < m_height) {
            m_buffer[ty * m_width + tx] = color;
        }
    }

    // Text positioning
    void setCursor(int16_t x, int16_t y) {
        m_cursorX = x;
        m_cursorY = y;
    }

    int16_t getCursorX() const { return m_cursorX; }
    int16_t getCursorY() const { return m_cursorY; }

    // Text colors
    void setTextColor(PixelType color) {
        m_textColor = color;
        m_bgColor = color; // No background when single color
    }

    void setTextColor(PixelType color, PixelType bg) {
        m_textColor = color;
        m_bgColor = bg;
    }

    // Font selection
    void setFont(const GFXfont* font = nullptr) {
        m_font = font;
    }

    const GFXfont* getFont() const { return m_font; }

    // Text size multiplier
    void setTextSize(uint8_t size) {
        m_textSize = (size > 0) ? size : 1;
    }

    // Text wrapping
    void setTextWrap(bool wrap) {
        m_wrap = wrap;
    }

    // Rotation (0-3 for 0, 90, 180, 270 degrees)
    void setRotation(uint8_t rotation) {
        m_rotation = rotation & 3;
    }

    uint8_t getRotation() const { return m_rotation; }

    // Print a single character
    size_t write(uint8_t c) {
        if (m_font) {
            // Custom GFX font
            if (c == '\n') {
                m_cursorX = 0;
                m_cursorY += m_textSize * static_cast<int16_t>(pgm_read_byte(&m_font->yAdvance));
            } else if (c != '\r') {
                uint16_t first = pgm_read_word(&m_font->first);
                uint16_t last = pgm_read_word(&m_font->last);
                
                if (c >= first && c <= last) {
                    GFXglyph* glyph = &((GFXglyph*)pgm_read_ptr(&m_font->glyph))[c - first];
                    uint8_t w = pgm_read_byte(&glyph->width);
                    uint8_t h = pgm_read_byte(&glyph->height);
                    
                    if (w > 0 && h > 0) {
                        int16_t xo = static_cast<int8_t>(pgm_read_byte(&glyph->xOffset));
                        
                        if (m_wrap && (m_cursorX + m_textSize * (xo + w) > m_width)) {
                            m_cursorX = 0;
                            m_cursorY += m_textSize * static_cast<int16_t>(pgm_read_byte(&m_font->yAdvance));
                        }
                        
                        drawChar(m_cursorX, m_cursorY, c, m_textColor, m_bgColor, m_textSize);
                    }
                    
                    m_cursorX += pgm_read_byte(&glyph->xAdvance) * m_textSize;
                }
            }
        } else {
            // Built-in 5x7 font
            if (c == '\n') {
                m_cursorX = 0;
                m_cursorY += m_textSize * 8;
            } else if (c != '\r') {
                if (m_wrap && (m_cursorX + m_textSize * 6 > m_width)) {
                    m_cursorX = 0;
                    m_cursorY += m_textSize * 8;
                }
                drawChar(m_cursorX, m_cursorY, c, m_textColor, m_bgColor, m_textSize);
                m_cursorX += m_textSize * 6;
            }
        }
        return 1;
    }

    // Print a string
    size_t print(const char* str) {
        size_t n = 0;
        while (*str) {
            n += write(static_cast<uint8_t>(*str++));
        }
        return n;
    }

    // Print a single character (overload)
    size_t print(char c) {
        return write(static_cast<uint8_t>(c));
    }

    // Get text bounds for a string
    void getTextBounds(const char* str, int16_t x, int16_t y, 
                       int16_t* x1, int16_t* y1, uint16_t* w, uint16_t* h) {
        int16_t minX = x, minY = y, maxX = x, maxY = y;
        int16_t cursorX = x, cursorY = y;
        
        while (*str) {
            uint8_t c = static_cast<uint8_t>(*str++);
            
            if (m_font) {
                uint16_t first = pgm_read_word(&m_font->first);
                uint16_t last = pgm_read_word(&m_font->last);
                
                if (c == '\n') {
                    cursorX = x;
                    cursorY += m_textSize * static_cast<int16_t>(pgm_read_byte(&m_font->yAdvance));
                } else if (c >= first && c <= last) {
                    GFXglyph* glyph = &((GFXglyph*)pgm_read_ptr(&m_font->glyph))[c - first];
                    int8_t xo = static_cast<int8_t>(pgm_read_byte(&glyph->xOffset));
                    int8_t yo = static_cast<int8_t>(pgm_read_byte(&glyph->yOffset));
                    uint8_t gw = pgm_read_byte(&glyph->width);
                    uint8_t gh = pgm_read_byte(&glyph->height);
                    
                    int16_t gx1 = cursorX + xo * m_textSize;
                    int16_t gy1 = cursorY + yo * m_textSize;
                    int16_t gx2 = gx1 + gw * m_textSize - 1;
                    int16_t gy2 = gy1 + gh * m_textSize - 1;
                    
                    minX = std::min(minX, gx1);
                    minY = std::min(minY, gy1);
                    maxX = std::max(maxX, gx2);
                    maxY = std::max(maxY, gy2);
                    
                    cursorX += pgm_read_byte(&glyph->xAdvance) * m_textSize;
                }
            } else {
                // Built-in font
                if (c == '\n') {
                    cursorX = x;
                    cursorY += m_textSize * 8;
                } else {
                    maxX = std::max(maxX, static_cast<int16_t>(cursorX + m_textSize * 5 - 1));
                    maxY = std::max(maxY, static_cast<int16_t>(cursorY + m_textSize * 7 - 1));
                    cursorX += m_textSize * 6;
                }
            }
        }
        
        *x1 = minX;
        *y1 = minY;
        *w = static_cast<uint16_t>(maxX - minX + 1);
        *h = static_cast<uint16_t>(maxY - minY + 1);
    }

protected:
    // Draw a single character at the specified position
    void drawChar(int16_t x, int16_t y, uint8_t c, PixelType color, 
                  PixelType bg, uint8_t size) {
        if (m_font) {
            drawCharGFX(x, y, c, color, size);
        } else {
            drawCharBuiltin(x, y, c, color, bg, size);
        }
    }

    // Draw character using GFX font
    void drawCharGFX(int16_t x, int16_t y, uint8_t c, PixelType color, uint8_t size) {
        uint16_t first = pgm_read_word(&m_font->first);
        uint16_t last = pgm_read_word(&m_font->last);
        
        if (c < first || c > last) return;
        
        c -= first;
        GFXglyph* glyph = &((GFXglyph*)pgm_read_ptr(&m_font->glyph))[c];
        uint8_t* bitmap = (uint8_t*)pgm_read_ptr(&m_font->bitmap);
        
        uint16_t bo = pgm_read_word(&glyph->bitmapOffset);
        uint8_t w = pgm_read_byte(&glyph->width);
        uint8_t h = pgm_read_byte(&glyph->height);
        int8_t xo = static_cast<int8_t>(pgm_read_byte(&glyph->xOffset));
        int8_t yo = static_cast<int8_t>(pgm_read_byte(&glyph->yOffset));
        
        uint8_t bits = 0, bit = 0;
        
        for (uint8_t yy = 0; yy < h; yy++) {
            for (uint8_t xx = 0; xx < w; xx++) {
                if (!(bit++ & 7)) {
                    bits = pgm_read_byte(&bitmap[bo++]);
                }
                if (bits & 0x80) {
                    if (size == 1) {
                        drawPixel(x + xo + xx, y + yo + yy, color);
                    } else {
                        fillRect(x + (xo + xx) * size, y + (yo + yy) * size, 
                                 size, size, color);
                    }
                }
                bits <<= 1;
            }
        }
    }

    // Draw character using built-in 5x7 font
    void drawCharBuiltin(int16_t x, int16_t y, uint8_t c, PixelType color, 
                         PixelType bg, uint8_t size) {
        // Built-in 5x7 font bitmap data (classic Adafruit GFX font)
        static const uint8_t font5x7[] PROGMEM = {
            0x00, 0x00, 0x00, 0x00, 0x00, // space
            0x00, 0x00, 0x5F, 0x00, 0x00, // !
            0x00, 0x07, 0x00, 0x07, 0x00, // "
            0x14, 0x7F, 0x14, 0x7F, 0x14, // #
            0x24, 0x2A, 0x7F, 0x2A, 0x12, // $
            0x23, 0x13, 0x08, 0x64, 0x62, // %
            0x36, 0x49, 0x55, 0x22, 0x50, // &
            0x00, 0x05, 0x03, 0x00, 0x00, // '
            0x00, 0x1C, 0x22, 0x41, 0x00, // (
            0x00, 0x41, 0x22, 0x1C, 0x00, // )
            0x08, 0x2A, 0x1C, 0x2A, 0x08, // *
            0x08, 0x08, 0x3E, 0x08, 0x08, // +
            0x00, 0x50, 0x30, 0x00, 0x00, // ,
            0x08, 0x08, 0x08, 0x08, 0x08, // -
            0x00, 0x60, 0x60, 0x00, 0x00, // .
            0x20, 0x10, 0x08, 0x04, 0x02, // /
            0x3E, 0x51, 0x49, 0x45, 0x3E, // 0
            0x00, 0x42, 0x7F, 0x40, 0x00, // 1
            0x42, 0x61, 0x51, 0x49, 0x46, // 2
            0x21, 0x41, 0x45, 0x4B, 0x31, // 3
            0x18, 0x14, 0x12, 0x7F, 0x10, // 4
            0x27, 0x45, 0x45, 0x45, 0x39, // 5
            0x3C, 0x4A, 0x49, 0x49, 0x30, // 6
            0x01, 0x71, 0x09, 0x05, 0x03, // 7
            0x36, 0x49, 0x49, 0x49, 0x36, // 8
            0x06, 0x49, 0x49, 0x29, 0x1E, // 9
            0x00, 0x36, 0x36, 0x00, 0x00, // :
            0x00, 0x56, 0x36, 0x00, 0x00, // ;
            0x00, 0x08, 0x14, 0x22, 0x41, // <
            0x14, 0x14, 0x14, 0x14, 0x14, // =
            0x41, 0x22, 0x14, 0x08, 0x00, // >
            0x02, 0x01, 0x51, 0x09, 0x06, // ?
            0x32, 0x49, 0x79, 0x41, 0x3E, // @
            0x7E, 0x11, 0x11, 0x11, 0x7E, // A
            0x7F, 0x49, 0x49, 0x49, 0x36, // B
            0x3E, 0x41, 0x41, 0x41, 0x22, // C
            0x7F, 0x41, 0x41, 0x22, 0x1C, // D
            0x7F, 0x49, 0x49, 0x49, 0x41, // E
            0x7F, 0x09, 0x09, 0x01, 0x01, // F
            0x3E, 0x41, 0x41, 0x51, 0x32, // G
            0x7F, 0x08, 0x08, 0x08, 0x7F, // H
            0x00, 0x41, 0x7F, 0x41, 0x00, // I
            0x20, 0x40, 0x41, 0x3F, 0x01, // J
            0x7F, 0x08, 0x14, 0x22, 0x41, // K
            0x7F, 0x40, 0x40, 0x40, 0x40, // L
            0x7F, 0x02, 0x04, 0x02, 0x7F, // M
            0x7F, 0x04, 0x08, 0x10, 0x7F, // N
            0x3E, 0x41, 0x41, 0x41, 0x3E, // O
            0x7F, 0x09, 0x09, 0x09, 0x06, // P
            0x3E, 0x41, 0x51, 0x21, 0x5E, // Q
            0x7F, 0x09, 0x19, 0x29, 0x46, // R
            0x46, 0x49, 0x49, 0x49, 0x31, // S
            0x01, 0x01, 0x7F, 0x01, 0x01, // T
            0x3F, 0x40, 0x40, 0x40, 0x3F, // U
            0x1F, 0x20, 0x40, 0x20, 0x1F, // V
            0x7F, 0x20, 0x18, 0x20, 0x7F, // W
            0x63, 0x14, 0x08, 0x14, 0x63, // X
            0x03, 0x04, 0x78, 0x04, 0x03, // Y
            0x61, 0x51, 0x49, 0x45, 0x43, // Z
            0x00, 0x00, 0x7F, 0x41, 0x41, // [
            0x02, 0x04, 0x08, 0x10, 0x20, // backslash
            0x41, 0x41, 0x7F, 0x00, 0x00, // ]
            0x04, 0x02, 0x01, 0x02, 0x04, // ^
            0x40, 0x40, 0x40, 0x40, 0x40, // _
            0x00, 0x01, 0x02, 0x04, 0x00, // `
            0x20, 0x54, 0x54, 0x54, 0x78, // a
            0x7F, 0x48, 0x44, 0x44, 0x38, // b
            0x38, 0x44, 0x44, 0x44, 0x20, // c
            0x38, 0x44, 0x44, 0x48, 0x7F, // d
            0x38, 0x54, 0x54, 0x54, 0x18, // e
            0x08, 0x7E, 0x09, 0x01, 0x02, // f
            0x08, 0x14, 0x54, 0x54, 0x3C, // g
            0x7F, 0x08, 0x04, 0x04, 0x78, // h
            0x00, 0x44, 0x7D, 0x40, 0x00, // i
            0x20, 0x40, 0x44, 0x3D, 0x00, // j
            0x00, 0x7F, 0x10, 0x28, 0x44, // k
            0x00, 0x41, 0x7F, 0x40, 0x00, // l
            0x7C, 0x04, 0x18, 0x04, 0x78, // m
            0x7C, 0x08, 0x04, 0x04, 0x78, // n
            0x38, 0x44, 0x44, 0x44, 0x38, // o
            0x7C, 0x14, 0x14, 0x14, 0x08, // p
            0x08, 0x14, 0x14, 0x18, 0x7C, // q
            0x7C, 0x08, 0x04, 0x04, 0x08, // r
            0x48, 0x54, 0x54, 0x54, 0x20, // s
            0x04, 0x3F, 0x44, 0x40, 0x20, // t
            0x3C, 0x40, 0x40, 0x20, 0x7C, // u
            0x1C, 0x20, 0x40, 0x20, 0x1C, // v
            0x3C, 0x40, 0x30, 0x40, 0x3C, // w
            0x44, 0x28, 0x10, 0x28, 0x44, // x
            0x0C, 0x50, 0x50, 0x50, 0x3C, // y
            0x44, 0x64, 0x54, 0x4C, 0x44, // z
            0x00, 0x08, 0x36, 0x41, 0x00, // {
            0x00, 0x00, 0x7F, 0x00, 0x00, // |
            0x00, 0x41, 0x36, 0x08, 0x00, // }
            0x08, 0x08, 0x2A, 0x1C, 0x08, // ~
            0x08, 0x1C, 0x2A, 0x08, 0x08, // DEL (custom arrow)
        };

        if (c < 32 || c > 127) c = 32; // Use space for unsupported chars
        c -= 32;

        bool hasBg = (color != bg);
        
        for (int8_t i = 0; i < 5; i++) {
            uint8_t line = pgm_read_byte(&font5x7[c * 5 + i]);
            for (int8_t j = 0; j < 8; j++) {
                if (line & 0x1) {
                    if (size == 1) {
                        drawPixel(x + i, y + j, color);
                    } else {
                        fillRect(x + i * size, y + j * size, size, size, color);
                    }
                } else if (hasBg) {
                    if (size == 1) {
                        drawPixel(x + i, y + j, bg);
                    } else {
                        fillRect(x + i * size, y + j * size, size, size, bg);
                    }
                }
                line >>= 1;
            }
        }
        
        // Draw column spacing
        if (hasBg) {
            if (size == 1) {
                for (int8_t j = 0; j < 8; j++) {
                    drawPixel(x + 5, y + j, bg);
                }
            } else {
                fillRect(x + 5 * size, y, size, 8 * size, bg);
            }
        }
    }

    // Fill a rectangle
    void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, PixelType color) {
        for (int16_t j = y; j < y + h; j++) {
            for (int16_t i = x; i < x + w; i++) {
                drawPixel(i, j, color);
            }
        }
    }

private:
    PixelType* m_buffer;
    int16_t m_width;
    int16_t m_height;
    int16_t m_cursorX;
    int16_t m_cursorY;
    PixelType m_textColor;
    PixelType m_bgColor;
    const GFXfont* m_font;
    uint8_t m_textSize;
    bool m_wrap;
    uint8_t m_rotation;
};

} // namespace lumyn::internal::ui
