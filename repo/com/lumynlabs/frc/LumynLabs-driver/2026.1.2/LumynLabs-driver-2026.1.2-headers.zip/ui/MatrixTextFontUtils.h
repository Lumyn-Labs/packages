// SPDX-License-Identifier: LGPL-2.1-or-later
// Utilities for MatrixTextFont calculations in simulation
#pragma once

#include "lumyn/domain/command/led/LEDCommand.h"
#include <cstdint>

namespace lumyn::internal::ui
{

/**
 * Get the approximate character width for a given MatrixTextFont.
 * These values are estimates for simulation display purposes and may
 * not exactly match the firmware's font metrics.
 * 
 * @param font The MatrixTextFont enum value
 * @return Approximate character width in pixels
 */
inline constexpr uint16_t GetMatrixTextFontCharWidth(Command::LED::MatrixTextFont font)
{
  switch (font)
  {
  case Command::LED::MatrixTextFont::BUILTIN:
    return 6;
  case Command::LED::MatrixTextFont::TINY_3X3:
  case Command::LED::MatrixTextFont::PICOPIXEL:
  case Command::LED::MatrixTextFont::TOM_THUMB:
    return 4;
  case Command::LED::MatrixTextFont::ORG_01:
    return 6;
  case Command::LED::MatrixTextFont::FREE_MONO_9:
  case Command::LED::MatrixTextFont::FREE_MONO_BOLD_9:
    return 11;
  case Command::LED::MatrixTextFont::FREE_SANS_9:
  case Command::LED::MatrixTextFont::FREE_SANS_BOLD_9:
  case Command::LED::MatrixTextFont::FREE_SERIF_9:
  case Command::LED::MatrixTextFont::FREE_SERIF_BOLD_9:
    return 8;
  case Command::LED::MatrixTextFont::FREE_MONO_12:
  case Command::LED::MatrixTextFont::FREE_MONO_BOLD_12:
    return 14;
  case Command::LED::MatrixTextFont::FREE_SANS_12:
  case Command::LED::MatrixTextFont::FREE_SANS_BOLD_12:
  case Command::LED::MatrixTextFont::FREE_SERIF_12:
  case Command::LED::MatrixTextFont::FREE_SERIF_BOLD_12:
    return 10;
  case Command::LED::MatrixTextFont::FREE_MONO_18:
  case Command::LED::MatrixTextFont::FREE_MONO_BOLD_18:
    return 21;
  case Command::LED::MatrixTextFont::FREE_SANS_18:
  case Command::LED::MatrixTextFont::FREE_SANS_BOLD_18:
  case Command::LED::MatrixTextFont::FREE_SERIF_18:
  case Command::LED::MatrixTextFont::FREE_SERIF_BOLD_18:
    return 14;
  case Command::LED::MatrixTextFont::FREE_MONO_24:
  case Command::LED::MatrixTextFont::FREE_MONO_BOLD_24:
    return 28;
  case Command::LED::MatrixTextFont::FREE_SANS_24:
  case Command::LED::MatrixTextFont::FREE_SANS_BOLD_24:
  case Command::LED::MatrixTextFont::FREE_SERIF_24:
  case Command::LED::MatrixTextFont::FREE_SERIF_BOLD_24:
    return 18;
  default:
    return 6;
  }
}

} // namespace lumyn::internal::ui
