#pragma once
#ifdef DESKTOP
/**
 * @file SimLedControlState.h
 * @brief LED zone control state types for the simulation UI.
 *
 * Contains enums and structs for managing zone control state in the LED tab.
 */

#include <array>
#include <cstdint>
#include "imgui.h"
#include "lumyn/domain/Color.h"
#include "lumyn/domain/command/led/LEDCommand.h"
#include "lumyn/configuration/configs/Zone.h"

namespace lumyn::internal
{
  /**
   * @brief Command modes available for zone control.
   */
  enum class ZoneCommandMode
  {
    Animation = 0,
    AnimationSequence,
    MatrixBitmap,
    MatrixText
  };

  /**
   * @brief State for zone control UI widgets.
   *
   * Holds staged command values for animation, sequence, bitmap, and text
   * commands until they are applied via the Start button.
   */
  struct ZoneControlState
  {
    ZoneCommandMode mode{ZoneCommandMode::Animation};
    Command::LED::SetAnimationData animation{};
    uint16_t sequenceId{0};
    Command::LED::SetBitmapData bitmap{};
    Command::LED::SetMatrixTextData matrixText{};
    std::array<char, 25> textBuffer{};
    bool animationInitialized{false};
    bool bitmapInitialized{false};
    bool textInitialized{false};
  };

  /**
   * @brief Returns a label string for the given zone command mode.
   * @param mode The zone command mode.
   * @return A human-readable label.
   */
  inline const char *GetZoneCommandModeLabel(ZoneCommandMode mode)
  {
    switch (mode)
    {
    case ZoneCommandMode::Animation:
      return "Animation";
    case ZoneCommandMode::AnimationSequence:
      return "Animation Sequence";
    case ZoneCommandMode::MatrixBitmap:
      return "Bitmap";
    case ZoneCommandMode::MatrixText:
      return "Text";
    }
    return "Command";
  }

  /**
   * @brief Visual representation of an LED in the strip visualization.
   */
  struct LedVisual
  {
    ImVec2 center{0.0f, 0.0f};
    float radius{0.0f};
    const Configuration::Zone *zone{nullptr};
    int ledIndex{0};
    domain::Color color{};
  };

  /**
   * @brief Information about a segment (zone) in the strip visualization.
   */
  struct ZoneSegment
  {
    const Configuration::Zone *zone{nullptr};
    uint32_t start{0};
    uint32_t count{0};
  };

  /**
   * @brief Information about a row in the LED strip layout.
   */
  struct RowInfo
  {
    int startIndex{0};
    int count{0};
    float top{0.0f};
    float bottom{0.0f};
    float left{0.0f};
    float right{0.0f};
  };

} // namespace lumyn::internal
#endif // DESKTOP
