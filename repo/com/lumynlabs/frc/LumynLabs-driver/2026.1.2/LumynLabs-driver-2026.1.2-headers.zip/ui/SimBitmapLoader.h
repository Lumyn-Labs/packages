// SPDX-License-Identifier: LGPL-2.1-or-later
// Bitmap loading and caching for simulation image sequences
// This module handles loading BMP files for matrix displays in simulation.
#pragma once

#ifdef DESKTOP

#include <cstdint>
#include <string>
#include <vector>
#include <array>
#include <optional>
#include <filesystem>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <unordered_map>
#include "lumyn/util/logging/ConsoleLogger.h"
#include "lumyn/configuration/Configuration.h"

namespace lumyn::internal {

/**
 * BitmapLoader provides BMP file loading and caching for the simulation.
 * It supports the same bitmap formats as the firmware:
 * - 1-bit monochrome
 * - 8-bit grayscale/indexed
 * - 16-bit RGB555
 */
namespace BitmapLoader {

#pragma pack(push, 1)
struct BMPHeader {
    uint16_t signature;   // "BM" (0x4D42)
    uint32_t fileSize;
    uint32_t reserved;
    uint32_t dataOffset;
    uint32_t headerSize;
    int32_t width;
    int32_t height;
    uint16_t planes;
    uint16_t bitsPerPixel;
    uint32_t compression;
    uint32_t imageSize;
};
#pragma pack(pop)

/**
 * Represents a single frame of bitmap data.
 * Pixels are stored as RGB, row-major, top-to-bottom (converted from BMP format).
 */
struct BitmapFrame {
    std::vector<uint8_t> pixels; // RGB data, 3 bytes per pixel
    int width = 0;
    int height = 0;
};

/**
 * Represents a sequence of bitmap frames (for animations).
 */
struct ImageSequence {
    std::string sourceKey;           // Unique key for cache lookup
    std::vector<BitmapFrame> frames; // Frame data
};

// Cache of loaded image sequences, keyed by bitmap ID
inline std::unordered_map<uint16_t, ImageSequence>& GetSequenceCache() {
    static std::unordered_map<uint16_t, ImageSequence> cache;
    return cache;
}

// Deploy path for locating bitmap files
inline std::string& GetDeployPathRef() {
    static std::string path;
    return path;
}

inline void SetDeployPath(const std::string& path) {
    GetDeployPathRef() = path;
}

inline std::string GetDeployPath() {
    return GetDeployPathRef();
}

/**
 * Extract a color channel from a 16-bit pixel using a bitmask.
 */
inline uint8_t ExtractChannel(uint16_t pixel, uint32_t mask) {
    if (mask == 0) return 0;
    
    int shift = 0;
    uint32_t tmp = mask;
    while ((tmp & 1) == 0) {
        shift++;
        tmp >>= 1;
    }
    
    int bits = 0;
    while (tmp & 1) {
        bits++;
        tmp >>= 1;
    }
    
    if (bits == 0) return 0;
    
    uint32_t value = (pixel & mask) >> shift;
    uint32_t maxValue = (1u << bits) - 1;
    return static_cast<uint8_t>((value * 255 + maxValue / 2) / maxValue);
}

/**
 * Load a single BMP file into a BitmapFrame.
 * Supports 1-bit, 8-bit, and 16-bit BMP formats.
 * 
 * @param filepath Path to the BMP file
 * @param frame Output frame to populate
 * @return true if successful, false on error
 */
inline bool LoadBMP(const std::string& filepath, BitmapFrame& frame) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        return false;
    }

    BMPHeader header;
    file.read(reinterpret_cast<char*>(&header), sizeof(BMPHeader));

    // Validate BMP signature
    if (header.signature != 0x4D42) { // "BM"
        ConsoleLogger::getInstance().logError("BitmapLoader", 
            "LoadBMP - signature mismatch for %s sig=0x%x", filepath.c_str(), header.signature);
        return false;
    }

    // Support only firmware-backed BMP formats
    uint16_t bitsPerPixel = header.bitsPerPixel;
    if (bitsPerPixel != 1 && bitsPerPixel != 8 && bitsPerPixel != 16) {
        ConsoleLogger::getInstance().logError("BitmapLoader",
            "LoadBMP - unsupported bitsPerPixel=%d for file %s (supported: 1,8,16)",
            bitsPerPixel, filepath.c_str());
        return false;
    }

    frame.width = header.width;
    frame.height = std::abs(header.height);
    bool topDown = header.height < 0;

    // Default RGB555 masks for 16-bit
    uint32_t redMask = 0x7C00;
    uint32_t greenMask = 0x03E0;
    uint32_t blueMask = 0x001F;
    
    if ((header.compression == 3 || header.compression == 6) && bitsPerPixel == 16) {
        file.read(reinterpret_cast<char*>(&redMask), sizeof(redMask));
        file.read(reinterpret_cast<char*>(&greenMask), sizeof(greenMask));
        file.read(reinterpret_cast<char*>(&blueMask), sizeof(blueMask));
    }

    frame.pixels.resize(frame.width * frame.height * 3);

    // Read color palette for indexed formats
    std::vector<uint8_t> palette;
    if (bitsPerPixel == 1 || bitsPerPixel == 8) {
        uint32_t paletteOffset = 14 + header.headerSize;
        uint32_t paletteSize = header.dataOffset - paletteOffset;
        if (paletteSize > 0 && paletteSize <= 1024) {
            file.seekg(paletteOffset, std::ios::beg);
            palette.resize(paletteSize);
            file.read(reinterpret_cast<char*>(palette.data()), paletteSize);
        }
    }

    file.seekg(header.dataOffset, std::ios::beg);

    if (bitsPerPixel == 1) {
        // 1-bit monochrome
        int bytesPerRowRaw = (frame.width + 7) / 8;
        int rowSize = ((bytesPerRowRaw + 3) / 4) * 4;
        int pixelDataSize = rowSize * frame.height;
        std::vector<uint8_t> rawData(pixelDataSize);
        file.read(reinterpret_cast<char*>(rawData.data()), pixelDataSize);

        for (int y = 0; y < frame.height; ++y) {
            int srcY = topDown ? y : (frame.height - 1 - y);
            for (int x = 0; x < frame.width; ++x) {
                int byteIdx = srcY * rowSize + (x / 8);
                int bitIdx = 7 - (x % 8);
                uint8_t idx = (rawData[byteIdx] >> bitIdx) & 0x1;
                int dstIdx = (y * frame.width + x) * 3;
                
                if (palette.size() >= static_cast<size_t>((idx + 1) * 4)) {
                    frame.pixels[dstIdx + 0] = palette[idx * 4 + 2]; // R
                    frame.pixels[dstIdx + 1] = palette[idx * 4 + 1]; // G
                    frame.pixels[dstIdx + 2] = palette[idx * 4 + 0]; // B
                } else {
                    uint8_t v = idx ? 255 : 0;
                    frame.pixels[dstIdx + 0] = v;
                    frame.pixels[dstIdx + 1] = v;
                    frame.pixels[dstIdx + 2] = v;
                }
            }
        }
    } else if (bitsPerPixel == 8) {
        // 8-bit indexed
        int bytesPerPixel = 1;
        int rowSize = ((frame.width * bytesPerPixel + 3) / 4) * 4;
        int pixelDataSize = rowSize * frame.height;
        std::vector<uint8_t> rawData(pixelDataSize);
        file.read(reinterpret_cast<char*>(rawData.data()), pixelDataSize);

        for (int y = 0; y < frame.height; ++y) {
            int srcY = topDown ? y : (frame.height - 1 - y);
            for (int x = 0; x < frame.width; ++x) {
                int srcIdx = srcY * rowSize + x * bytesPerPixel;
                int dstIdx = (y * frame.width + x) * 3;
                uint8_t paletteIdx = rawData[srcIdx];
                
                if (palette.size() >= static_cast<size_t>((paletteIdx + 1) * 4)) {
                    frame.pixels[dstIdx + 0] = palette[paletteIdx * 4 + 2]; // R
                    frame.pixels[dstIdx + 1] = palette[paletteIdx * 4 + 1]; // G
                    frame.pixels[dstIdx + 2] = palette[paletteIdx * 4 + 0]; // B
                } else {
                    frame.pixels[dstIdx + 0] = paletteIdx;
                    frame.pixels[dstIdx + 1] = paletteIdx;
                    frame.pixels[dstIdx + 2] = paletteIdx;
                }
            }
        }
    } else { // 16-bit
        int bytesPerPixel = 2;
        int rowSize = ((frame.width * bytesPerPixel + 3) / 4) * 4;
        int pixelDataSize = rowSize * frame.height;
        std::vector<uint8_t> rawData(pixelDataSize);
        file.read(reinterpret_cast<char*>(rawData.data()), pixelDataSize);

        for (int y = 0; y < frame.height; ++y) {
            int srcY = topDown ? y : (frame.height - 1 - y);
            for (int x = 0; x < frame.width; ++x) {
                int srcIdx = srcY * rowSize + x * bytesPerPixel;
                int dstIdx = (y * frame.width + x) * 3;
                uint16_t pixel = static_cast<uint16_t>(rawData[srcIdx]) |
                                (static_cast<uint16_t>(rawData[srcIdx + 1]) << 8);
                frame.pixels[dstIdx + 0] = ExtractChannel(pixel, redMask);
                frame.pixels[dstIdx + 1] = ExtractChannel(pixel, greenMask);
                frame.pixels[dstIdx + 2] = ExtractChannel(pixel, blueMask);
            }
        }
    }

    return true;
}

/**
 * Resolve a file path, checking both absolute and deploy-relative paths.
 */
inline std::optional<std::filesystem::path> ResolveFilePath(const std::string& path) {
    std::error_code ec;
    std::filesystem::path candidate(path);
    if (candidate.is_absolute() && std::filesystem::exists(candidate, ec)) {
        return candidate;
    }

    std::string deploy = GetDeployPath();
    if (deploy.empty()) {
        return std::nullopt;
    }

    std::array<std::filesystem::path, 2> attempts = {
        std::filesystem::path(deploy) / path,
        std::filesystem::path(deploy) / "connectorx" / path
    };
    
    for (const auto& attempt : attempts) {
        if (std::filesystem::exists(attempt, ec)) {
            return attempt;
        }
    }
    
    ConsoleLogger::getInstance().logInfo("BitmapLoader",
        "ResolveFilePath - could not find file '%s' under deploy path '%s'",
        path.c_str(), deploy.c_str());
    return std::nullopt;
}

/**
 * Resolve a folder path, checking both absolute and deploy-relative paths.
 */
inline std::optional<std::filesystem::path> ResolveFolderPath(const std::string& folder) {
    std::error_code ec;
    std::filesystem::path candidate(folder);
    if (candidate.is_absolute() && std::filesystem::is_directory(candidate, ec)) {
        return candidate;
    }

    std::string deploy = GetDeployPath();
    if (deploy.empty()) {
        return std::nullopt;
    }

    std::array<std::filesystem::path, 2> attempts = {
        std::filesystem::path(deploy) / "connectorx" / folder,
        std::filesystem::path(deploy) / folder
    };
    
    for (const auto& attempt : attempts) {
        if (std::filesystem::is_directory(attempt, ec)) {
            return attempt;
        }
    }
    
    ConsoleLogger::getInstance().logInfo("BitmapLoader",
        "ResolveFolderPath - could not find folder '%s' under deploy path '%s'",
        folder.c_str(), deploy.c_str());
    return std::nullopt;
}

/**
 * Load all frames from an animated bitmap folder.
 * Expects firmware-style numeric sequence (0.bmp, 1.bmp, 2.bmp, etc.)
 */
inline bool LoadAnimatedFrames(const std::filesystem::path& dir, ImageSequence& sequence) {
    std::error_code ec;
    if (!std::filesystem::is_directory(dir, ec)) {
        return false;
    }

    // Require 0.bmp to exist (firmware convention)
    std::filesystem::path zeroPath = dir / "0.bmp";
    if (!std::filesystem::exists(zeroPath)) {
        ConsoleLogger::getInstance().logInfo("BitmapLoader",
            "LoadAnimatedFrames - missing required 0.bmp in %s", dir.string().c_str());
        return false;
    }

    std::vector<std::filesystem::path> fileList;
    for (const auto& entry : std::filesystem::directory_iterator(dir, ec)) {
        if (ec) continue;
        if (!entry.is_regular_file(ec)) continue;
        
        auto ext = entry.path().extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(),
                      [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (ext == ".bmp") {
            fileList.push_back(entry.path());
        }
    }
    
    if (fileList.empty()) {
        ConsoleLogger::getInstance().logInfo("BitmapLoader",
            "LoadAnimatedFrames - no BMP files found in %s", dir.string().c_str());
        return false;
    }

    // Sort by trailing numeric suffix
    auto extractTrailingDigits = [](const std::string& s) -> std::optional<long> {
        int i = static_cast<int>(s.size()) - 1;
        while (i >= 0 && std::isdigit(static_cast<unsigned char>(s[i]))) --i;
        int start = i + 1;
        if (start >= static_cast<int>(s.size())) return std::nullopt;
        std::string digits = s.substr(start);
        try {
            return std::stol(digits);
        } catch (...) {
            return std::nullopt;
        }
    };

    std::sort(fileList.begin(), fileList.end(),
        [&](const std::filesystem::path& a, const std::filesystem::path& b) {
            const std::string aStem = a.stem().string();
            const std::string bStem = b.stem().string();
            auto aNum = extractTrailingDigits(aStem);
            auto bNum = extractTrailingDigits(bStem);
            if (aNum && bNum) return aNum.value() < bNum.value();
            if (aNum) return true;
            if (bNum) return false;
            return aStem < bStem;
        });

    for (const auto& framePath : fileList) {
        BitmapFrame frame;
        if (LoadBMP(framePath.string(), frame)) {
            sequence.frames.push_back(std::move(frame));
        }
    }

    ConsoleLogger::getInstance().logInfo("BitmapLoader",
        "LoadAnimatedFrames - loaded %u frames from %s",
        static_cast<unsigned>(sequence.frames.size()), dir.string().c_str());
    return !sequence.frames.empty();
}

/**
 * Build a cache key for a bitmap configuration.
 */
inline std::string BuildSourceKey(const Configuration::Bitmap& info) {
    if (info.type == Configuration::BitmapType::Animated && info.folder) {
        return "anim:" + *info.folder;
    }
    if (info.type == Configuration::BitmapType::Static && info.path) {
        return "static:" + *info.path;
    }
    return "";
}

/**
 * Load a bitmap by ID, using cache when available.
 * 
 * @param bitmapId The bitmap ID for caching
 * @param info Bitmap configuration
 * @return Pointer to cached ImageSequence, or nullptr on failure
 */
inline const ImageSequence* LoadBitmap(uint16_t bitmapId, const Configuration::Bitmap& info) {
    std::string sourceKey = BuildSourceKey(info);
    if (sourceKey.empty()) {
        return nullptr;
    }

    auto& cache = GetSequenceCache();
    auto cached = cache.find(bitmapId);
    if (cached != cache.end() && cached->second.sourceKey == sourceKey) {
        return &cached->second;
    }

    ImageSequence loaded{};
    loaded.sourceKey = sourceKey;
    bool success = false;
    
    if (info.type == Configuration::BitmapType::Animated) {
        if (!info.folder) return nullptr;
        
        auto folderPath = ResolveFolderPath(*info.folder);
        if (!folderPath) {
            ConsoleLogger::getInstance().logError("BitmapLoader",
                "LoadBitmap - folder not found for animated bitmap: %s", info.folder->c_str());
            return nullptr;
        }
        
        ConsoleLogger::getInstance().logInfo("BitmapLoader",
            "LoadBitmap - folder path resolved to %s", folderPath->string().c_str());
        success = LoadAnimatedFrames(*folderPath, loaded);
        ConsoleLogger::getInstance().logInfo("BitmapLoader",
            "LoadBitmap - loaded %u frames for '%s'",
            static_cast<unsigned>(loaded.frames.size()), info.folder->c_str());
    } else {
        if (!info.path) return nullptr;
        
        auto filePath = ResolveFilePath(*info.path);
        if (!filePath) return nullptr;
        
        BitmapFrame frame;
        if (!LoadBMP(filePath->string(), frame)) {
            return nullptr;
        }
        loaded.frames.push_back(std::move(frame));
        success = true;
    }

    if (!success || loaded.frames.empty()) {
        return nullptr;
    }

    auto& entry = cache[bitmapId];
    entry = std::move(loaded);
    return &entry;
}

/**
 * Clear the bitmap cache.
 */
inline void ClearCache() {
    GetSequenceCache().clear();
}

} // namespace BitmapLoader

} // namespace lumyn::internal

#endif // DESKTOP
