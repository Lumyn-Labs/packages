#pragma once
#ifdef DESKTOP
/**
 * @file SimModuleControlState.h
 * @brief Module control state types for the simulation UI.
 *
 * Contains structs for managing module field state in the Modules tab.
 */

#include <cstdint>
#include <vector>
#include <optional>
#include "lumyn/domain/module/ModulePayloadDescriptor.h"

namespace lumyn::internal
{
  namespace module_ns = ::lumyn::internal::module;

  /**
   * @brief State for a single module field.
   */
  struct ModuleFieldState
  {
    module_ns::FieldType type{module_ns::FieldType::kUInt8};
    uint64_t integerValue{0};
    double floatingValue{0.0};
  };

  /**
   * @brief State for the entire module form UI.
   */
  struct ModuleFormState
  {
    int unitId{1};
    std::vector<ModuleFieldState> fields;
    // Last received data for display (persists even after data is consumed by user code)
    std::optional<std::pair<uint16_t, std::vector<uint8_t>>> lastReceived;
  };

} // namespace lumyn::internal
#endif // DESKTOP
