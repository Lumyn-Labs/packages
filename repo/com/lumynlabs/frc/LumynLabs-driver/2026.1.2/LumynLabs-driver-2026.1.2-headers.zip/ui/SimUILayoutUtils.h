// SPDX-License-Identifier: LGPL-2.1-or-later
// UI Constants and layout utilities for Connector-X simulation
#pragma once

#ifdef DESKTOP

#include <vector>
#include <cmath>
#include <algorithm>
#include "imgui.h"

namespace lumyn::internal {

/**
 * UI Constants for the simulation GUI.
 * These control sizing, spacing, and layout of the strip visualization.
 */
namespace UIConstants {
    constexpr float kStripDefaultWidth = 600.0f;
    constexpr float kStripMinWidth = 120.0f;
    constexpr float kStripHeight = 40.0f;
    constexpr float kStripPadding = 10.0f;
    constexpr float kRowSpacing = 6.0f;
    constexpr float kLedSpacing = 18.0f;
    constexpr float kLedRadius = 7.0f;
    constexpr float kMinLedRadius = 2.5f;
    constexpr float kMaxLedRadius = 12.0f;
    constexpr float kStatusLEDRadius = 0.45f;
} // namespace UIConstants

/**
 * Layout information for a responsive LED strip visualization.
 * Supports multi-row layouts when LEDs don't fit in a single row.
 */
struct ResponsiveStripLayout {
    float ledRadius{UIConstants::kLedRadius};
    float ledSpacing{UIConstants::kLedSpacing};
    float rowSpacing{UIConstants::kRowSpacing};
    float totalHeight{UIConstants::kStripHeight};
    std::vector<int> rowCounts;
    std::vector<float> rowIndents;
};

// Pixel outline color for matrix/LED visualization
static constexpr ImU32 kPixelOutlineColor = IM_COL32(100, 100, 100, 100);

/**
 * Draw a rounded pixel (used for matrix displays).
 */
inline void DrawRoundedPixel(ImDrawList *list, const ImVec2 &center, float halfSize, ImU32 color, ImU32 outlineColor = kPixelOutlineColor) {
    float rounding = halfSize * 0.45f;
    ImVec2 topLeft(center.x - halfSize, center.y - halfSize);
    ImVec2 bottomRight(center.x + halfSize, center.y + halfSize);
    list->AddRectFilled(topLeft, bottomRight, color, rounding);
    list->AddRect(topLeft, bottomRight, outlineColor, rounding);
}

/**
 * Draw a dark grid background for matrix displays.
 */
inline void DrawGridBackground(ImDrawList *list, const ImVec2 &topLeft, const ImVec2 &size, float rounding = 3.0f) {
    list->AddRectFilled(topLeft, topLeft + size, IM_COL32(20, 20, 20, 255), rounding);
}

/**
 * Calculate responsive layout for an LED strip given available width and LED count.
 * Automatically wraps to multiple rows if necessary.
 */
inline ResponsiveStripLayout CalculateResponsiveStripLayout(float innerWidth, int totalLedCount) {
    ResponsiveStripLayout layout{};
    layout.totalHeight = UIConstants::kStripHeight;
    if (totalLedCount <= 0 || innerWidth <= 0.0f) {
        return layout;
    }

    const float minLedSize = 8.0f;
    const float maxLedSize = std::max(12.0f, innerWidth * 0.06f);
    const float minSpacing = minLedSize / 0.45f;

    int maxPerRow = std::max(1, static_cast<int>(std::floor(innerWidth / std::max(minSpacing, 1.0f))));
    int numRows = 1;
    if (totalLedCount > maxPerRow) {
        numRows = static_cast<int>(std::ceil(static_cast<float>(totalLedCount) / maxPerRow));
    }

    layout.rowCounts.assign(numRows, 0);
    for (int i = 0; i < numRows; ++i) {
        layout.rowCounts[i] = totalLedCount / numRows;
    }
    int remainder = totalLedCount % numRows;
    for (int i = 0; i < remainder; ++i) {
        layout.rowCounts[i]++;
    }

    int maxRowLen = 0;
    for (int count : layout.rowCounts) {
        maxRowLen = std::max(maxRowLen, count);
    }

    float approxSpacing = innerWidth / std::max(1, maxRowLen);
    float ledDiameter = std::clamp(approxSpacing * 0.6f, minLedSize, maxLedSize);
    layout.ledRadius = ledDiameter * 0.5f;
    layout.ledSpacing = std::max(ledDiameter + 4.0f, approxSpacing);
    layout.rowSpacing = layout.ledRadius * 1.8f;
    layout.totalHeight = numRows * (layout.ledRadius * 2.0f);
    if (numRows > 1) {
        layout.totalHeight += (numRows - 1) * layout.rowSpacing;
    }

    layout.rowIndents.assign(numRows, 0.0f);
    for (int row = 0; row < numRows; ++row) {
        int count = layout.rowCounts[row];
        float rowWidth = count > 1 ? (count - 1) * layout.ledSpacing : 0.0f;
        float indent = std::max(0.0f, (innerWidth - rowWidth) * 0.5f);
        layout.rowIndents[row] = indent;
    }

    return layout;
}

/**
 * Calculate layout with fixed LED size (for synchronized sizing across channels).
 */
inline ResponsiveStripLayout CalculateResponsiveStripLayoutWithFixedSize(float innerWidth, int totalLedCount, float fixedLedRadius, float fixedLedSpacing) {
    ResponsiveStripLayout layout{};
    layout.ledRadius = fixedLedRadius;
    layout.ledSpacing = fixedLedSpacing;
    layout.rowSpacing = fixedLedRadius * 1.8f;
    layout.totalHeight = UIConstants::kStripHeight;
    if (totalLedCount <= 0 || innerWidth <= 0.0f) {
        return layout;
    }

    // Calculate how many LEDs fit per row with the fixed spacing
    int maxPerRow = std::max(1, static_cast<int>(std::floor(innerWidth / std::max(fixedLedSpacing, 1.0f))));
    int numRows = 1;
    if (totalLedCount > maxPerRow) {
        numRows = static_cast<int>(std::ceil(static_cast<float>(totalLedCount) / maxPerRow));
    }

    layout.rowCounts.assign(numRows, 0);
    for (int i = 0; i < numRows; ++i) {
        layout.rowCounts[i] = totalLedCount / numRows;
    }
    int remainder = totalLedCount % numRows;
    for (int i = 0; i < remainder; ++i) {
        layout.rowCounts[i]++;
    }

    layout.totalHeight = numRows * (fixedLedRadius * 2.0f);
    if (numRows > 1) {
        layout.totalHeight += (numRows - 1) * layout.rowSpacing;
    }

    layout.rowIndents.assign(numRows, 0.0f);
    for (int row = 0; row < numRows; ++row) {
        int count = layout.rowCounts[row];
        float rowWidth = count > 1 ? (count - 1) * fixedLedSpacing : 0.0f;
        float indent = std::max(0.0f, (innerWidth - rowWidth) * 0.5f);
        layout.rowIndents[row] = indent;
    }

    return layout;
}

} // namespace lumyn::internal

#endif // DESKTOP
