#pragma once

#include <units/time.h>
#include <optional>
#include <vector>
#include <string>
#include <cstddef>
#include <unordered_map>
#include <memory>
#include "lumyn/connectorXVariant/ConnectorX.h"
#include "lumyn/util/serial/ISerialIO.h"
#include "lumyn/util/serial/UsbSerialIO.h"
#include "lumyn/util/serial/UartSerialIO.h"
#include "lumyn/connection/USBPort.h"
#include "lumyn/connection/UARTPort.h"
#include <lumyn/c/lumyn_common.h>
// Include common headers for Eventing and led types (needed for C API declarations)
#include "lumyn/domain/event/Event.h"
#include "lumyn/led/Animation.h"
#include "lumyn/domain/command/led/LEDCommand.h"

#ifdef DESKTOP
#include <imgui.h>
#include "HALSimExt.h"
#include "hal/Extensions.h"
#include "ui/ConnectorXSimUI.h"
#endif

// Forward declaration for DirectBufferManager
namespace lumyn::internal
{
  class DirectBufferManager;
}

struct DirectBufferManagerDeleter
{
  void operator()(lumyn::internal::DirectBufferManager *ptr) const;
};

namespace lumyn::internal::c_ConnectorX
{
  class LUMYN_SDK_API ConnectorX_int
  {
  public:
    // Delete copy operations (unordered_map with unique_ptr values is not copyable)
    ConnectorX_int() = default;
    ConnectorX_int(const ConnectorX_int &) = delete;
    ConnectorX_int &operator=(const ConnectorX_int &) = delete;
    ConnectorX_int(ConnectorX_int &&) = default;
    ConnectorX_int &operator=(ConnectorX_int &&) = default;

#ifdef LUMYN_COMPILE_DRIVER_LAYER
    // Driver layer: full type available
    ConnectorX &GetInner()
    {
      if (!_inst)
      {
        _inst = new ConnectorX();
      }

      return *_inst;
    }
#else
    // Native API: forward declaration only, implementation in .cpp
    // Note: Native API doesn't instantiate or destroy ConnectorX_int directly,
    // it only uses pointers from C API functions
    lumyn::device::ConnectorX &GetInner();
#endif
    // Destructor: always non-inline to work with incomplete type in native API
    // Implementation provided in .cpp file
    ~ConnectorX_int();

    void SetUseSim(bool useSim)
    {
      _useSim = useSim;
    }

    bool UseSim() const
    {
      return _useSim;
    }

    // Set the product SKU for simulation (value corresponds to SimProductSku enum)
    void SetSimSku(uint16_t sku)
    {
      _simSku = sku;
    }

    uint16_t GetSimSku() const
    {
      return _simSku;
    }

    /**
     * Get or create a DirectBufferManager for a zone.
     * @param zoneId Zone identifier string
     * @param bufferLength Expected buffer length in bytes (numLEDs * 3 for RGB)
     * @param fullRefreshInterval Send full buffer every N frames (default: 100)
     * @return Reference to the DirectBufferManager
     */
    DirectBufferManager &GetOrCreateDirectBuffer(const std::string &zoneId, size_t bufferLength, int fullRefreshInterval = 100);

    /**
     * Check if a DirectBufferManager exists for a zone.
     */
    bool HasDirectBuffer(const std::string &zoneId) const;

    /**
     * Get an existing DirectBufferManager (returns nullptr if not found).
     */
    DirectBufferManager *GetDirectBuffer(const std::string &zoneId);

    /**
     * Remove a DirectBufferManager for a zone.
     */
    void RemoveDirectBuffer(const std::string &zoneId);

    /**
     * Clear all DirectBufferManagers.
     */
    void ClearDirectBuffers();

  private:
    // Forward declaration for native API, full type for driver layer
    // ConnectorX is forward declared in lumyn/connectorXVariant/ConnectorX.h
    lumyn::device::ConnectorX *_inst = nullptr;
    std::unordered_map<std::string, std::unique_ptr<DirectBufferManager, DirectBufferManagerDeleter>> _directBuffers;
    bool _useSim = true;
    uint16_t _simSku = 0; // SimProductSku::kUnknown
  };

#ifdef __cplusplus
  extern "C"
  {
#endif
    /**
     * MUST BE DELETED
     */
    LUMYN_SDK_API ConnectorX_int *cx_CreateInstance(void);
    LUMYN_SDK_API void cx_DestroyInstance(ConnectorX_int *inst);

    LUMYN_SDK_API bool cx_Connect(ConnectorX_int *, lumyn::connection::USBPort port);
    LUMYN_SDK_API bool cx_ConnectUart(ConnectorX_int *, lumyn::connection::UARTPort port, int baud);
    // Connect using a custom ISerialIO implementation (takes ownership)
    LUMYN_SDK_API bool cx_ConnectSerial(ConnectorX_int *, lumyn::internal::ISerialIO *serial);
    LUMYN_SDK_API bool cx_IsConnected(ConnectorX_int *);
    LUMYN_SDK_API Eventing::Status cx_GetCurrentStatus(ConnectorX_int *);
    LUMYN_SDK_API bool cx_GetLatestEvent(ConnectorX_int *, Eventing::Event *);

    LUMYN_SDK_API int cx_GetEvents(ConnectorX_int *inst, lumyn::internal::Eventing::Event *arr, int maxCount);

    // If modules are enabled for the variant...
    // Returns latest data entries for the module id, if available (id + bytes)
    LUMYN_SDK_API bool cx_GetLatestData(ConnectorX_int *, const char *, std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &);
    
    // Module polling control
    LUMYN_SDK_API void cx_SetModulePollingEnabled(ConnectorX_int *, bool enabled);
    LUMYN_SDK_API bool cx_RegisterModule(ConnectorX_int *, const char *moduleId);
    LUMYN_SDK_API void cx_PollModules(ConnectorX_int *);

    // If LEDs are enabled for the variant...
    LUMYN_SDK_API void cx_SetColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    LUMYN_SDK_API void cx_SetGroupColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    LUMYN_SDK_API void cx_SetAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                         units::millisecond_t, bool reversed = false, bool oneShot = false);
    LUMYN_SDK_API void cx_SetGroupAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                              units::millisecond_t, bool reversed = false, bool oneShot = false);
    LUMYN_SDK_API void cx_SetAnimationSequence(ConnectorX_int *, const char *, const char *);
    LUMYN_SDK_API void cx_SetGroupAnimationSequence(ConnectorX_int *, const char *, const char *);

    LUMYN_SDK_API void cx_SetBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                      bool setColor = false, bool oneShot = false);
    LUMYN_SDK_API void cx_SetGroupBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                           bool setColor = false, bool oneShot = false);
    LUMYN_SDK_API void cx_SetText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                    Command::LED::MatrixTextScrollDirection, units::millisecond_t, bool,
                    Command::LED::AnimationColor bgColor = {0, 0, 0},
                    Command::LED::MatrixTextFont font = Command::LED::MatrixTextFont::BUILTIN,
                    Command::LED::MatrixTextAlign align = Command::LED::MatrixTextAlign::LEFT,
                    Command::LED::MatrixTextFlags flags = {0, 0, 0, 0, 0},
                    int8_t yOffset = 0);
    LUMYN_SDK_API void cx_SetGroupText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                         Command::LED::MatrixTextScrollDirection, units::millisecond_t, bool,
                         Command::LED::AnimationColor bgColor = {0, 0, 0},
                         Command::LED::MatrixTextFont font = Command::LED::MatrixTextFont::BUILTIN,
                         Command::LED::MatrixTextAlign align = Command::LED::MatrixTextAlign::LEFT,
                         Command::LED::MatrixTextFlags flags = {0, 0, 0, 0, 0},
                         int8_t yOffset = 0);

    // Direct LED Buffer API
    // Creates or retrieves a DirectBufferManager for efficient delta-compressed LED updates

    /**
     * Create or get a DirectBufferManager for a zone.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @param bufferLength Expected buffer length in bytes (numLEDs * 3 for RGB)
     * @param fullRefreshInterval Send full buffer every N frames (0 to disable periodic refresh)
     * @return true if successful
     */
    LUMYN_SDK_API bool cx_CreateDirectBuffer(ConnectorX_int *inst, const char *zoneId, size_t bufferLength, int fullRefreshInterval);

    /**
     * Update a direct LED buffer with automatic delta compression.
     * Creates command bytes and sends them to the device.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @param data Raw RGB bytes (3 bytes per LED: R, G, B)
     * @param length Number of bytes in data
     * @return true if successful, false if zone not found or length mismatch
     */
    LUMYN_SDK_API bool cx_UpdateDirectBuffer(ConnectorX_int *inst, const char *zoneId, const uint8_t *data, size_t length);

    /**
     * Force a full (non-delta) update of a direct LED buffer.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @param data Raw RGB bytes
     * @param length Number of bytes in data
     * @return true if successful
     */
    LUMYN_SDK_API bool cx_ForceFullDirectBuffer(ConnectorX_int *inst, const char *zoneId, const uint8_t *data, size_t length);

    /**
     * Reset a direct buffer's state, forcing next update to be full.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     */
    LUMYN_SDK_API void cx_ResetDirectBuffer(ConnectorX_int *inst, const char *zoneId);

    /**
     * Remove a direct buffer manager for a zone.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     */
    LUMYN_SDK_API void cx_RemoveDirectBuffer(ConnectorX_int *inst, const char *zoneId);

    /**
     * Set the full refresh interval for a direct buffer.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @param interval New interval (0 to disable)
     */
    LUMYN_SDK_API void cx_SetDirectBufferRefreshInterval(ConnectorX_int *inst, const char *zoneId, int interval);

    /**
     * Get the expected buffer length for a direct buffer.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @return Buffer length in bytes, or 0 if zone not found
     */
    LUMYN_SDK_API size_t cx_GetDirectBufferLength(ConnectorX_int *inst, const char *zoneId);

    // Requests
    LUMYN_SDK_API bool cx_RequestConfig(ConnectorX_int *, std::string &outJson);
    LUMYN_SDK_API void cx_RestartDevice(ConnectorX_int *, uint16_t delayMs);
    LUMYN_SDK_API void cx_ApplyConfigurationJson(ConnectorX_int *, const char *jsonData, size_t length);

    // Simulation helper
    LUMYN_SDK_API void cx_SetDeployPath(const char *path);

#ifdef __cplusplus
  }
#endif

#ifdef DESKTOP

  inline void initSimGui()
  {
    static bool initialized = false;
    if (initialized)
    {
      return;
    }
    initialized = true;

    HAL_RegisterExtensionListener(nullptr, [](void *, const char *name, void *data)
                                  {
      if (std::string_view{name} == HALSIMGUI_EXT_ADDGUILATEEXECUTE) {
        reinterpret_cast<::lumyn::internal::sim::AddGuiLateExecuteFn>(data)([]() {
          ConnectorXSimUI::GetInstance().render();
        });
      } else if (std::string_view{name} == HALSIMGUI_EXT_ADDGUIINIT) {
        reinterpret_cast<::lumyn::internal::sim::AddGuiInitFn>(data)([]() {
          ConnectorXSimUI::GetInstance().init();
        });
      } else if (std::string_view{name} == HALSIMGUI_EXT_GETIMGUICONTEXT) {
        ImGuiContext* context = reinterpret_cast<::lumyn::internal::sim::GetImGuiContextFn>(data)();
        if (context) {
          ConnectorXSimUI::GetInstance().setImGuiContext(context);
        }
      } });
  }
#endif // DESKTOP
} // namespace lumyn::internal::c_ConnectorX
