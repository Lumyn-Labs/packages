#pragma once

#include "lumyn/domain/event/Event.h"
#include <lumyn/c/lumyn_common.h>
#include <string>

namespace lumyn::utils {

LUMYN_SDK_API std::string GetDisabledCauseText(lumyn::internal::Eventing::DisabledCause cause);
LUMYN_SDK_API std::string GetErrorTypeText(lumyn::internal::Eventing::ErrorType type);
LUMYN_SDK_API std::string GetFatalErrorTypeText(lumyn::internal::Eventing::FatalErrorType type);

} // namespace lumyn::utils

#ifdef __cplusplus
extern "C" {
#endif

LUMYN_SDK_API const char* Lumyn_GetDisabledCauseText(int cause);
LUMYN_SDK_API const char* Lumyn_GetErrorTypeText(int type);
LUMYN_SDK_API const char* Lumyn_GetFatalErrorTypeText(int type);

#ifdef __cplusplus
}
#endif
