#pragma once

// Compatibility header for lumyn-c-sdk migration
// Redirects to the new ConnectorX.hpp from lumyn-c-sdk
// Note: This is needed by driver layer's c_ConnectorX.h
// The SDK's lumyn::device::ConnectorX and vendordep's lumyn::device::ConnectorX
// are in the same namespace but serve different purposes and are kept separate
// by only including SDK headers when compiling the driver layer

#ifdef LUMYN_COMPILE_DRIVER_LAYER
// Driver layer needs full SDK header (lumyn-c-sdk/include is in the include path)
#include <lumyn/cpp/connectorXVariant/ConnectorX.hpp>
using lumyn::device::ConnectorX;
#else
// Native API only needs forward declaration to avoid namespace collisions
namespace lumyn {
  namespace device {
    class ConnectorX;
  }
}
#endif