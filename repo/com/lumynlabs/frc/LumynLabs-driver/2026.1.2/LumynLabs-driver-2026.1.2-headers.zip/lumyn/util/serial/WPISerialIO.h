#pragma once

#include "lumyn/util/serial/ISerialIO.h"
#include <hal/SerialPort.h>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <thread>
#include <atomic>
#include <vector>

namespace lumyn::internal {

/**
 * Base class for WPILib-based serial I/O implementations.
 * 
 * This class provides the common implementation for both USB and UART
 * serial communication using WPILib's HAL serial port APIs.
 * 
 * Subclasses (UsbSerialIO, UartSerialIO) exist primarily to provide
 * type-safe construction with appropriate port types.
 */
class WPISerialIO : public ISerialIO {
public:
    /**
     * Construct a WPILib serial I/O handler.
     * 
     * @param port The HAL serial port to use
     * @param baud The baud rate (default: 115200)
     * @param timeoutSeconds Read timeout in seconds (default: 0.001 = 1ms)
     */
    WPISerialIO(HAL_SerialPort port, int baud = 115200, double timeoutSeconds = 0.001);
    ~WPISerialIO() override;

    // Prevent copying
    WPISerialIO(const WPISerialIO&) = delete;
    WPISerialIO& operator=(const WPISerialIO&) = delete;

    // Allow moving
    WPISerialIO(WPISerialIO&& other) noexcept;
    WPISerialIO& operator=(WPISerialIO&& other) noexcept;

    /**
     * Open the serial port and start the read thread.
     * @return true if successful, false otherwise
     */
    bool open();

    /**
     * Close the serial port and stop the read thread.
     */
    void close();

    /**
     * Check if the serial port is currently open.
     */
    bool isOpen() const;

    // ISerialIO interface
    void writeBytes(const uint8_t* data, size_t length) override;
    void setReadCallback(std::function<void(const uint8_t*, size_t)> callback) override;

protected:
    /**
     * Called by writeBytes before writing. Subclasses can override
     * to implement chunking or other write modifications.
     * Default implementation writes directly.
     * 
     * @param data The data to write
     * @param length The length of the data
     */
    virtual void doWrite(const uint8_t* data, size_t length);

private:
    void startReadThread();
    void stopReadThread();

    HAL_SerialPort _port;
    int _baud;
    double _timeoutSeconds;
    std::atomic<bool> _isOpen;
    std::atomic<bool> _readThreadRunning;
    std::thread _readThread;
    HAL_SerialPortHandle _serialHandle;
    std::function<void(const uint8_t*, size_t)> _readCallback;
    mutable std::mutex _callbackMutex;  // Protects _readCallback
};

} // namespace lumyn::internal
