#pragma once

#include "lumyn/util/serial/WPISerialIO.h"

namespace lumyn::internal {

/**
 * USB serial I/O implementation using WPILib's HAL.
 * 
 * This is a thin wrapper around WPISerialIO that provides type-safe
 * construction for USB serial ports. The implementation is identical
 * to UART serial - both use the same HAL APIs.
 */
class UsbSerialIO : public WPISerialIO {
public:
    /**
     * Construct a USB serial I/O handler.
     * 
     * @param port The HAL serial port to use (should be a USB port)
     * @param baud The baud rate (default: 115200)
     */
    UsbSerialIO(HAL_SerialPort port, int baud = 115200)
        : WPISerialIO(port, baud) {}
    
    ~UsbSerialIO() override = default;
};

} // namespace lumyn::internal
