#pragma once

#include "lumyn/util/serial/WPISerialIO.h"

namespace lumyn::internal {

/**
 * UART serial I/O implementation using WPILib's HAL.
 * 
 * This is a thin wrapper around WPISerialIO that provides type-safe
 * construction for UART serial ports. The implementation is identical
 * to USB serial - both use the same HAL APIs.
 */
class UartSerialIO : public WPISerialIO {
public:
    /**
     * Construct a UART serial I/O handler.
     * 
     * @param port The HAL serial port to use (should be a UART port like MXP)
     * @param baud The baud rate (default: 115200)
     */
    UartSerialIO(HAL_SerialPort port, int baud = 115200)
        : WPISerialIO(port, baud) {}
    
    ~UartSerialIO() override = default;
};

} // namespace lumyn::internal
