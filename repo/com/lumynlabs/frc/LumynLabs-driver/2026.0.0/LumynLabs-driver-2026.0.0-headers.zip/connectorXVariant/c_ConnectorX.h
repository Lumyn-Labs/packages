#pragma once

#include <units/time.h>
#include <optional>
#include <vector>
#include <string>
#include <cstddef>
#include <unordered_map>
#include <memory>
#include "lumyn/connectorXVariant/ConnectorX.h"
#include "lumyn/util/serial/ISerialIO.h"
#include "lumyn/util/serial/UsbSerialIO.h"
#include "lumyn/util/serial/UartSerialIO.h"
#include "lumyn/connection/USBPort.h"
#include "lumyn/connection/UARTPort.h"
#include "lumyn/led/DirectBufferManager.h"

#ifdef DESKTOP
#include <imgui.h>
#include "HALSimExt.h"
#include "hal/Extensions.h"
#include "ui/ConnectorXSimUI.h"
#endif

namespace lumyn::internal::c_ConnectorX
{
  class ConnectorX_int
  {
  public:
    ConnectorX &GetInner()
    {
      if (!_inst)
      {
        _inst = new ConnectorX();
      }

      return *_inst;
    }

    ~ConnectorX_int()
    {
      if (_inst)
      {
        delete _inst;
      }
    }

    /**
     * Get or create a DirectBufferManager for a zone.
     * @param zoneId Zone identifier string
     * @param bufferLength Expected buffer length in bytes (numLEDs * 3 for RGB)
     * @param fullRefreshInterval Send full buffer every N frames (default: 100)
     * @return Reference to the DirectBufferManager
     */
    DirectBufferManager &GetOrCreateDirectBuffer(const std::string &zoneId, size_t bufferLength, int fullRefreshInterval = 100)
    {
      auto it = _directBuffers.find(zoneId);
      if (it == _directBuffers.end())
      {
        auto [inserted, success] = _directBuffers.emplace(
            zoneId,
            std::make_unique<DirectBufferManager>(zoneId, bufferLength, fullRefreshInterval));
        return *inserted->second;
      }
      return *it->second;
    }

    /**
     * Check if a DirectBufferManager exists for a zone.
     */
    bool HasDirectBuffer(const std::string &zoneId) const
    {
      return _directBuffers.find(zoneId) != _directBuffers.end();
    }

    /**
     * Get an existing DirectBufferManager (returns nullptr if not found).
     */
    DirectBufferManager *GetDirectBuffer(const std::string &zoneId)
    {
      auto it = _directBuffers.find(zoneId);
      if (it != _directBuffers.end())
      {
        return it->second.get();
      }
      return nullptr;
    }

    /**
     * Remove a DirectBufferManager for a zone.
     */
    void RemoveDirectBuffer(const std::string &zoneId)
    {
      _directBuffers.erase(zoneId);
    }

    /**
     * Clear all DirectBufferManagers.
     */
    void ClearDirectBuffers()
    {
      _directBuffers.clear();
    }

  private:
    ConnectorX *_inst = nullptr;
    std::unordered_map<std::string, std::unique_ptr<DirectBufferManager>> _directBuffers;
  };

#ifdef __cplusplus
  extern "C"
  {
#endif
    /**
     * MUST BE DELETED
     */
    ConnectorX_int *cx_CreateInstance(void);

    bool cx_Connect(ConnectorX_int *, lumyn::connection::USBPort port);
    bool cx_ConnectUart(ConnectorX_int *, lumyn::connection::UARTPort port, int baud);
    bool cx_IsConnected(ConnectorX_int *);
    Eventing::Status cx_GetCurrentStatus(ConnectorX_int *);
    bool cx_GetLatestEvent(ConnectorX_int *, Eventing::Event *);

    int cx_GetEvents(ConnectorX_int *inst, lumyn::internal::Eventing::Event *arr, int maxCount);

    // If modules are enabled for the variant...
    // Returns latest data entries for the module id, if available (id + bytes)
    bool cx_GetLatestData(ConnectorX_int *, const char *, std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &);

    // If LEDs are enabled for the variant...
    void cx_SetColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetGroupColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                         units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetGroupAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                              units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetAnimationSequence(ConnectorX_int *, const char *, const char *);
    void cx_SetGroupAnimationSequence(ConnectorX_int *, const char *, const char *);

    void cx_SetBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                      bool setColor = false, bool oneShot = false);
    void cx_SetGroupBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                           bool setColor = false, bool oneShot = false);
    void cx_SetText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor, Command::LED::MatrixTextScrollDirection, units::millisecond_t, bool);
    void cx_SetGroupText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor, Command::LED::MatrixTextScrollDirection, units::millisecond_t, bool);

    // Direct LED Buffer API
    // Creates or retrieves a DirectBufferManager for efficient delta-compressed LED updates

    /**
     * Create or get a DirectBufferManager for a zone.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @param bufferLength Expected buffer length in bytes (numLEDs * 3 for RGB)
     * @param fullRefreshInterval Send full buffer every N frames (0 to disable periodic refresh)
     * @return true if successful
     */
    bool cx_CreateDirectBuffer(ConnectorX_int *inst, const char *zoneId, size_t bufferLength, int fullRefreshInterval);

    /**
     * Update a direct LED buffer with automatic delta compression.
     * Creates command bytes and sends them to the device.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @param data Raw RGB bytes (3 bytes per LED: R, G, B)
     * @param length Number of bytes in data
     * @return true if successful, false if zone not found or length mismatch
     */
    bool cx_UpdateDirectBuffer(ConnectorX_int *inst, const char *zoneId, const uint8_t *data, size_t length);

    /**
     * Force a full (non-delta) update of a direct LED buffer.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @param data Raw RGB bytes
     * @param length Number of bytes in data
     * @return true if successful
     */
    bool cx_ForceFullDirectBuffer(ConnectorX_int *inst, const char *zoneId, const uint8_t *data, size_t length);

    /**
     * Reset a direct buffer's state, forcing next update to be full.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     */
    void cx_ResetDirectBuffer(ConnectorX_int *inst, const char *zoneId);

    /**
     * Remove a direct buffer manager for a zone.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     */
    void cx_RemoveDirectBuffer(ConnectorX_int *inst, const char *zoneId);

    /**
     * Set the full refresh interval for a direct buffer.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @param interval New interval (0 to disable)
     */
    void cx_SetDirectBufferRefreshInterval(ConnectorX_int *inst, const char *zoneId, int interval);

    /**
     * Get the expected buffer length for a direct buffer.
     * @param inst ConnectorX instance
     * @param zoneId Zone identifier string
     * @return Buffer length in bytes, or 0 if zone not found
     */
    size_t cx_GetDirectBufferLength(ConnectorX_int *inst, const char *zoneId);

    // Requests
    bool cx_RequestConfig(ConnectorX_int *, std::string &outJson);
    void cx_RestartDevice(ConnectorX_int *, uint16_t delayMs);
    void cx_ApplyConfigurationJson(ConnectorX_int *, const char *jsonData, size_t length);

    // Simulation helper
    void cx_SetDeployPath(const char *path);

#ifdef __cplusplus
  }
#endif

#ifdef DESKTOP

  inline void initSimGui()
  {
    static bool initialized = false;
    if (initialized)
    {
      return;
    }
    initialized = true;

    HAL_RegisterExtensionListener(nullptr, [](void *, const char *name, void *data)
                                  {
      if (std::string_view{name} == HALSIMGUI_EXT_ADDGUILATEEXECUTE) {
        reinterpret_cast<::lumyn::internal::sim::AddGuiLateExecuteFn>(data)([]() {
          ConnectorXSimUI::GetInstance().render();
        });
      } else if (std::string_view{name} == HALSIMGUI_EXT_ADDGUIINIT) {
        reinterpret_cast<::lumyn::internal::sim::AddGuiInitFn>(data)([]() {
          ConnectorXSimUI::GetInstance().init();
        });
      } else if (std::string_view{name} == HALSIMGUI_EXT_GETIMGUICONTEXT) {
        ImGuiContext* context = reinterpret_cast<::lumyn::internal::sim::GetImGuiContextFn>(data)();
        if (context) {
          ConnectorXSimUI::GetInstance().setImGuiContext(context);
        }
      } });
  }
#endif // DESKTOP
} // namespace lumyn::internal::c_ConnectorX
