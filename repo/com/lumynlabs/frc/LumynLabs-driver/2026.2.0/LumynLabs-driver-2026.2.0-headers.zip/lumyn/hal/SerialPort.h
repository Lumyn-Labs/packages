// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#pragma once

#include <hal/SerialPort.h>

#ifdef __cplusplus
extern "C" {
#endif

HAL_SerialPortHandle LUMYN_HAL_InitializeSerialPort(HAL_SerialPort port,
                                                    int32_t* status);
HAL_SerialPortHandle LUMYN_HAL_InitializeSerialPortDirect(
    HAL_SerialPort port, const char* portName, int32_t* status);
int LUMYN_HAL_GetSerialFD(HAL_SerialPortHandle handle, int32_t* status);
void LUMYN_HAL_SetSerialBaudRate(HAL_SerialPortHandle handle, int32_t baud,
                                 int32_t* status);
void LUMYN_HAL_SetSerialDataBits(HAL_SerialPortHandle handle, int32_t bits,
                                 int32_t* status);
void LUMYN_HAL_SetSerialParity(HAL_SerialPortHandle handle, int32_t parity,
                               int32_t* status);
void LUMYN_HAL_SetSerialStopBits(HAL_SerialPortHandle handle, int32_t stopBits,
                                 int32_t* status);
void LUMYN_HAL_SetSerialWriteMode(HAL_SerialPortHandle handle, int32_t mode,
                                  int32_t* status);
void LUMYN_HAL_SetSerialFlowControl(HAL_SerialPortHandle handle, int32_t flow,
                                    int32_t* status);
void LUMYN_HAL_SetSerialTimeout(HAL_SerialPortHandle handle, double timeout,
                                int32_t* status);
void LUMYN_HAL_EnableSerialTermination(HAL_SerialPortHandle handle,
                                       char terminator, int32_t* status);
void LUMYN_HAL_DisableSerialTermination(HAL_SerialPortHandle handle,
                                        int32_t* status);
void LUMYN_HAL_SetSerialReadBufferSize(HAL_SerialPortHandle handle,
                                       int32_t size, int32_t* status);
void LUMYN_HAL_SetSerialWriteBufferSize(HAL_SerialPortHandle handle,
                                        int32_t size, int32_t* status);
int32_t LUMYN_HAL_GetSerialBytesReceived(HAL_SerialPortHandle handle,
                                         int32_t* status);
int32_t LUMYN_HAL_ReadSerial(HAL_SerialPortHandle handle, char* buffer,
                             int32_t count, int32_t* status);
int32_t LUMYN_HAL_WriteSerial(HAL_SerialPortHandle handle, const char* buffer,
                              int32_t count, int32_t* status);
void LUMYN_HAL_FlushSerial(HAL_SerialPortHandle handle, int32_t* status);
void LUMYN_HAL_ClearSerial(HAL_SerialPortHandle handle, int32_t* status);
void LUMYN_HAL_CloseSerial(HAL_SerialPortHandle handle);

#ifdef __cplusplus
}  // extern "C"
#endif
